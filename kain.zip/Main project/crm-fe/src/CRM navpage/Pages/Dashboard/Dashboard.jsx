import React, { useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBarsStaggered, faGaugeHigh, faUser } from "@fortawesome/free-solid-svg-icons";
import TotalCustomersCard from "./Charts/Card/TotalCustomer";
import PipelineStatusChart from "./Charts/Doughnutchart/Piechrt";
import { useNavigate } from "react-router-dom";
import styles from './Dashboard.module.css'; 

export const Dashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div>
      <div className={styles.center_heading} >
      <h2 className={styles.dashboard_crm_charts_h2}>
        <FontAwesomeIcon
          style={{ color: "green", fontSize: "25px" }}
          icon={faGaugeHigh}
        />{" "}
        Dashboard
      </h2>
      </div>
      <div className={styles.dashboard_crm_charts}>
        <div className={styles.chart_crm}>
        <div className={styles.center_heading}>
        <h3 style={{ marginTop: "10px", fontSize: "25px" }}>
            <FontAwesomeIcon
              style={{
                color: "yellow",
                fontSize: "25px",
              }}
              icon={faUser}
            />{" "}
            Total Customers
          </h3>
          </div>
          <hr
          style={{
            width: "220px",
            position:"relative",
            left:"50%",
            transform:"translate(-50%)"
            
          }}/>
          
          <TotalCustomersCard />
        </div>
        <div className={styles.chart_crm} style={{ position: "relative", right: "40px" }}>
        <div className={styles.center_heading}>
        <h3 style={{ marginTop: "10px", fontSize: "23px" }}>
          <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faBarsStaggered}
                />{" "}
            Pipeline Status Distribution
          </h3>
          </div>
          <hr
          style={{
            width: "300px",
            position:"relative",
            left:"50%",
            transform:"translate(-50%)"
            
          }}/>
          <PipelineStatusChart />
        </div>
      </div>
    </div>
  );
};

