import React, { useEffect, useState } from "react";
import "./Totalcustomer.css";
import axiosInstance from "../../../../../Utils/axiosInstance";
import { useNavigate } from "react-router-dom";

const TotalCustomersCard = () => {
  const [totalCustomers, setTotalCustomers] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchTotalCustomers = async () => {
        try {
            const response = await axiosInstance.get("/ins/totalcustomer");
            setTotalCustomers(response.data.totalCustomers); // Assuming this is how data is returned
        } catch (err) {
            // Checking if the error response status is 401 (Unauthorized)
            if (err.response && err.response.status === 401) {
                const errorMessage = err.response.data.message;

                // If token is blacklisted, show an alert and redirect to login page
                if (errorMessage) {
                    // alert(errorMessage);
                    
                    localStorage.removeItem("token");  // Remove the blacklisted token from localStorage
                    localStorage.removeItem("hash");
                    navigate("/");  // Redirect to login page
                } else {
                    setError(errorMessage || "An error occurred. Please try again.");
                }
            } else {
                // Handle other errors (e.g., server errors, network errors)
                console.error("Error fetching customer count:", err);
                setError("Could not fetch total customer count.");
            }
        } finally {
            setLoading(false);
        }
    };
      fetchTotalCustomers();
}, [navigate]); 

  return (
    <div className="total-customers-card">
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="error">{error}</p>
      ) : (
        <div className="card-content">{totalCustomers}</div>
      )}
    </div>
  );
};

export default TotalCustomersCard;
