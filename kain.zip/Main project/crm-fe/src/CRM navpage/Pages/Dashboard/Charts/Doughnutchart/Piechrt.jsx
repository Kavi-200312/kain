// PipelineStatusChart.js
import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../Utils/axiosInstance";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { useNavigate } from "react-router-dom";

// Register Chart.js elements
ChartJS.register(ArcElement, Tooltip, Legend);

const PipelineStatusChart = () => {

  const navigate = useNavigate()
  const [statusCounts, setStatusCounts] = useState({
    Referral: 0,
    Lead: 0,
    InDiscussion: 0,
    Customer: 0,
    Closed: 0,
  });

  useEffect(() => {
    // Fetch status counts from the API
    const fetchStatusCounts = async () => {
      try {
        const response = await axiosInstance.get("/ins/status-counts");
        setStatusCounts(response.data.data);
       
      } catch (error) {
        if (error.response && error.response.status === 401) {
          const errorMessage = error.response.data.message;

          // If token is blacklisted, show an alert and redirect to login page
          if (errorMessage) {
              localStorage.removeItem("token");  // Remove the blacklisted token from localStorage
              localStorage.removeItem("hash");
              navigate("/");  // Redirect to login page
          } 
      } else {
          // Handle other errors (e.g., server errors, network errors)
          console.error("Error fetching Pipeline status:", error);
      }
      }
    };

    fetchStatusCounts();
  }, []);

  // Prepare data for the Doughnut chart
  const chartData = {
    labels: ["Referral", "Lead", "In Discussion", "Customer", "Closed"],
    datasets: [
      {
        data: [
          statusCounts.Referral,
          statusCounts.Lead,
          statusCounts.InDiscussion,
          statusCounts.Customer,
          statusCounts.Closed,
        ],
        backgroundColor: [
          "#FF6384",
          "#36A2EB",
          "#FFCE56",
          "#4BC0C0",
          "#9966FF",
        ],
        hoverBackgroundColor: [
          "#FF6384",
          "#36A2EB",
          "#FFCE56",
          "#4BC0C0",
          "#9966FF",
        ],
      },
    ],
  };

  return (
    <div
      style={{
        width: "70%",
        marginLeft: "70px",
        borderRadius: "5px",
        marginTop: "10px",
      }}
    >
      <Doughnut data={chartData} />
    </div>
  );
};

export default PipelineStatusChart;
