import React, { useState, useEffect } from "react";
import "./Customer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPhone,
  faComment,
  faPerson,
  faAddressCard,
  faEnvelope,
  faUserPlus,
  faPersonMilitaryPointing,
  faXmark,
  faClipboardList,
} from "@fortawesome/free-solid-svg-icons";
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axiosInstance from "../../../Utils/axiosInstance";
import { faPaperPlane } from "@fortawesome/free-solid-svg-icons/faPaperPlane";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const GeneralUsersList = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/");
    }
  }, [navigate]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    contactNumber: "",
    email: "",
    whatsappNumber: "",
  });
  const [customerList, setCustomerList] = useState([]);
  const [whatsappEnabled, setWhatsappEnabled] = useState(false);
  const [smsContent, setSmsContent] = useState("");
  const [smsErrors, setSmsErrors] = useState({});
  const [fetchError, setFetchError] = useState(null);
  const [showSmsPopup, setShowSmsPopup] = useState(false);
  const [showPolicyPopup, setShowPolicyPopup] = useState(false);
  const [customerPolicyDetails, setcustomerPolicyDetails] = useState([]);
  const [currentCustomer, setCurrentCustomer] = useState(null);

  const [errors, setErrors] = useState({
    name: "",
    contactNumber: "",
    email: "",
    whatsappNumber: "",
  });

  useEffect(() => {
    const fetchCustomers = async () => {
      setLoading(true);
      setFetchError(null);
      try {
        const response = await axiosInstance.get("/ins/getCustomers");
        setCustomerList(response.data.data);
        if (response.data.code === 401) {
          localStorage.removeItem("token");
          localStorage.removeItem("hash");
          alert(response.data.message);
          navigate("/");
        }
      } catch (error) {
        // if (error.response.data.code === 401) {
        //   localStorage.removeItem("token");
        //   localStorage.removeItem("hash");
        //   navigate("/");
        // }
        console.error("Error fetching customers:", error);
        setFetchError("Failed to load customers. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchCustomers();
  }, [showForm]);

  const validateIndianNumber = (number) => /^[6-9]\d{9}$/.test(number);
  const validateEmail = (email) =>
    /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email);
  const validateSmsContent = (content) =>
    /^[a-zA-Z0-9.,!?"' ]{1,160}$/.test(content);

  const handleKeyPressNumber = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if (charCode < 48 || charCode > 57) {
      e.preventDefault();
    }
  };

  const handleKeyPressString = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
      e.preventDefault();
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    // Update the formData state with the new input value
    setFormData({ ...formData, [name]: value });

    // Create a copy of errors object to modify dynamically
    let formErrors = { ...errors };

    // Perform field validation based on field name
    switch (name) {
      case "name":
        if (!value) {
          formErrors.name = "Name is required.";
        } else if (/\s/.test(value)) {
          formErrors.name = "Name cannot contain spaces.";
        } else {
          formErrors.name = ""; // No error
        }
        break;

      case "contactNumber":
        if (!value) {
          formErrors.contactNumber = "Contact number is required.";
        } else if (!validateIndianNumber(value)) {
          formErrors.contactNumber =
            "Must be a 10-digit number starting with 6-9.";
        } else if (/\s/.test(value)) {
          formErrors.contactNumber = "No spaces allowed.";
        } else {
          formErrors.contactNumber = ""; // No error
        }
        break;

      case "email":
        if (!value) {
          formErrors.email = "Email is required.";
        } else if (!validateEmail(value)) {
          formErrors.email = "Please enter a valid email address.";
        } else if (/\s/.test(value)) {
          formErrors.email = "Email cannot contain spaces.";
        } else {
          formErrors.email = ""; // No error
        }
        break;

      case "whatsappNumber":
        if (whatsappEnabled) {
          if (!validateIndianNumber(value)) {
            formErrors.whatsappNumber =
              "Must be a 10-digit number starting with 6-9.";
          } else if (/\s/.test(value)) {
            formErrors.whatsappNumber = "No spaces allowed.";
          } else {
            formErrors.whatsappNumber = ""; // No error
          }
        }
        break;

      default:
        break;
    }

    // Update the errors state with the new formErrors
    setErrors(formErrors);
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent form submission

    // Object to store errors
    let formErrors = {};

    // Validate name
    if (!formData.name) {
      formErrors.name = "Name is required.";
    } else if (/\s/.test(formData.name)) {
      formErrors.name = "Name cannot contain spaces.";
    }

    // Validate contact number
    if (!formData.contactNumber) {
      formErrors.contactNumber = "Contact number is required.";
    } else if (!validateIndianNumber(formData.contactNumber)) {
      formErrors.contactNumber = "Must be a 10-digit number starting with 6-9.";
    } else if (/\s/.test(formData.contactNumber)) {
      formErrors.contactNumber = "No spaces allowed.";
    }

    // Validate email
    if (!formData.email) {
      formErrors.email = "Email is required.";
    } else if (!validateEmail(formData.email)) {
      formErrors.email = "Please enter a valid email address.";
    } else if (/\s/.test(formData.email)) {
      formErrors.email = "Email cannot contain spaces.";
    }

    // Validate WhatsApp number (only if checkbox is checked)
    if (whatsappEnabled && !formData.whatsappNumber) {
      formErrors.whatsappNumber = "WhatsApp number is required.";
    } else if (
      whatsappEnabled &&
      !validateIndianNumber(formData.whatsappNumber)
    ) {
      formErrors.whatsappNumber =
        "Must be a 10-digit number starting with 6-9.";
    } else if (whatsappEnabled && /\s/.test(formData.whatsappNumber)) {
      formErrors.whatsappNumber = "No spaces allowed.";
    }

    // If no errors, submit the form
    if (Object.keys(formErrors).length === 0) {
      try {
        // Make an API call to save customer
        await axiosInstance.post("/ins/addcustomer", formData);
        toast.success("Customer added successfully", { autoClose: 2000 });

        // Reset the form
        setFormData({
          name: "",
          contactNumber: "",
          email: "",
          whatsappNumber: "",
        });
        setWhatsappEnabled(false);
        setShowForm(false); // Close the form
      } catch (error) {
        // Handle API errors
        console.error("Error saving customer:", error);
        setFetchError(
          error.response?.data?.message ||
            "Failed to save customer. Please try again."
        );
        toast.error("Failed to save customer. Please try again.", {
          autoClose: 3000,
        });
      }
    } else {
      // If there are validation errors, update the errors state
      setErrors(formErrors);
    }
  };

  // const handleSms = async () => {
  //   if (!validateSmsContent(smsContent)) {
  //     setSmsErrors({
  //       smsContent: "SMS content is invalid or exceeds 160 characters.",
  //     });
  //     return;
  //   }
  //   try {
  //     await axiosInstance.post("/ins/savesms", {
  //       customerNumber: currentCustomer.contactNumber,
  //       content: smsContent,
  //     });
  //     toast.success("SMS sent successfully!", { autoClose: 3000 });
  //     setSmsContent("");
  //     setShowSmsPopup(false);
  //   } catch (error) {
  //     if (error.response.data.code === 401) {
  //       localStorage.removeItem("token");
  //       navigate("/");
  //     }
  //     console.error("Error sending SMS:", error);
  //     const errorMessage =
  //       error.response?.data?.error || "Failed to send SMS. Please try again.";
  //     toast.error(errorMessage, { autoClose: 3000 });
  //   }
  // };

  const handleSms = async () => {
    if (!validateSmsContent(smsContent)) {
      setSmsErrors({
        smsContent: "SMS content is invalid or exceeds 160 characters.",
      });
      return;
    }

    try {
      // Send SMS request to the backend
      await axiosInstance.post("/ins/savesms", {
        customerNumber: currentCustomer.contactNumber,
        content: smsContent,
      });
      toast.success("SMS sent successfully!", { autoClose: 3000 });
      setSmsContent("");
      setShowSmsPopup(false);
    } catch (error) {
      // Check if the error has a response and handle it accordingly
      if (error.response) {
        // Specific handling when response exists
        if (error.response.data.code === 401) {
          localStorage.removeItem("token");
          navigate("/"); // Redirect to login
        }
        const errorMessage =
          error.response?.data?.error ||
          "Failed to send SMS. Please try again.";
        toast.error(errorMessage, { autoClose: 3000 });
      } else {
        // Generic error handling when response doesn't exist (e.g., network error)
        console.error("Error sending SMS:", error);
        setShowSmsPopup(false);
        toast.error("Network error or no response from the server.", {
          autoClose: 3000,
        });
      }
    }
  };

  const handleCall = async (customer) => {
    try {
      const response = await axiosInstance.post("/ins/trai/b2b/voice", {
        CustomerNumber: customer.contactNumber,
      });
      toast.success(`Call initiated to ${customer.name}`, { autoClose: 3000 });
      // console.log("Call response:", response.data);
    } catch (error) {
      if (error.response.data.code === 401) {
        localStorage.removeItem("token");
        navigate("/");
      }
      console.error("Error initiating call:", error);
      toast.error(error.response?.data?.message || "Failed to initiate call.", {
        autoClose: 3000,
      });
    }
  };

  const handleSmsButtonClick = (customer) => {
    setCurrentCustomer(customer);
    setSmsContent("");
    setShowSmsPopup(true);
  };

  const handlePolicyButtonClick = async (customer) => {
    try {
      const response = await axiosInstance.get("/ins/getPolicyDetails");
      const filteredPolicies = response.data.data.filter((policy) => {
        // Assuming `contactNumber` is available in both `customer` and `policy`
        return policy.contactNumber === customer.contactNumber;
      });
      // console.log(filteredPolicies);
      // Check if there are any filtered policies with status 'closed'
      const closedPolicies = filteredPolicies.filter(
        (policy) => policy.status === "Closed"
      );

      // If we have policies with status 'Closed', update the state
      if (closedPolicies.length > 0) {
        setcustomerPolicyDetails(closedPolicies);
      } else {
        // console.log("No closed policies found for this customer.");
      }
      setShowPolicyPopup(true);
    } catch (error) {
      // console.log(error.message, "can't retrive the data");
      toast.error(error.response?.data?.message || "can't retrive the data", {
        autoClose: 3000,
      });
    }
  };

  return (
    <div className="listform">
      <ToastContainer />
      <h2>
        <FontAwesomeIcon
          style={{ color: "green", fontSize: "29px" }}
          icon={faPersonMilitaryPointing}
        />{" "}
        Customer Details
      </h2>
      <div className="crm_addcustomer_form">
        <button onClick={() => setShowForm(true)}>
          <FontAwesomeIcon icon={faUserPlus} /> Add Customer
        </button>
      </div>
      <br />
      {loading && <p>Loading customers...</p>}
      {fetchError && <p className="error">{fetchError}</p>}
      <table>
        <thead>
          <tr>
            <th>
              <FontAwesomeIcon icon={faPerson} /> Name
            </th>
            <th>
              <FontAwesomeIcon icon={faAddressCard} /> Contact Number
            </th>
            <th>
              <FontAwesomeIcon icon={faEnvelope} /> Email Id
            </th>
            <th>
              <FontAwesomeIcon icon={faWhatsapp} /> WhatsApp No
            </th>
            <th>
              <FontAwesomeIcon icon={faPhone} /> Call to Customers
            </th>
            <th>
              <FontAwesomeIcon icon={faComment} /> SMS
            </th>
            <th>
              <FontAwesomeIcon icon={faClipboardList} /> Policy
            </th>
          </tr>
        </thead>
        <tbody>
          {customerList.length > 0 ? (
            customerList.map((customer) => (
              <tr key={customer._id}>
                <td>{customer.name}</td>
                <td>{customer.contactNumber}</td>
                <td>{customer.email}</td>
                <td>{customer.whatsappNumber || "N/A"}</td>
                <td>
                  <button
                    className="call_button"
                    style={{ backgroundColor: "green" }}
                    onClick={() => handleCall(customer)}
                  >
                    <FontAwesomeIcon icon={faPhone} /> Call
                  </button>
                </td>
                <td>
                  <button
                    className="call_button"
                    style={{ backgroundColor: "blue" }}
                    onClick={() => handleSmsButtonClick(customer)}
                  >
                    <FontAwesomeIcon icon={faComment} /> SMS
                  </button>
                </td>
                <td>
                  <button
                    className="call_button"
                    style={{ backgroundColor: "#626F47" }}
                    onClick={() => handlePolicyButtonClick(customer)}
                  >
                    <FontAwesomeIcon icon={faClipboardList} /> Policy
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td style={{ fontSize: "17px", fontWeight: "400" }} colSpan="6">
                No data available
              </td>
            </tr>
          )}
        </tbody>
      </table>
      {showForm && (
        <div className="popup" onClick={() => setShowForm(false)}>
          <div className="popup-content" onClick={(e) => e.stopPropagation()}>
            <h3>Add New Customer</h3>
            <form onSubmit={handleSubmit} autoComplete="off">
              <div>
                <label htmlFor="name">Name:</label>
                <input
                  type="text"
                  name="name"
                  maxLength={25}
                  pattern="^[A-Za-z\s]+$"
                  id="name"
                  title="Only letters can be accepted"
                  onKeyPress={handleKeyPressString}
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
                {errors.name && <p className="error">{errors.name}</p>}
              </div>

              <div>
                <label htmlFor="contactNumber">Contact Number:</label>
                <input
                  type="text"
                  name="contactNumber"
                  maxLength={10}
                  pattern="[6-9][0-9]{9}"
                  title="Only valid 10-digit Indian numbers"
                  id="contactNumber"
                  onKeyPress={handleKeyPressNumber}
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  required
                />
                {errors.contactNumber && (
                  <p className="error">{errors.contactNumber}</p>
                )}
              </div>

              <div>
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  name="email"
                  maxLength={30}
                  id="email"
                  title="Must be a valid email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
                {errors.email && <p className="error">{errors.email}</p>}
              </div>

              <div>
                <label htmlFor="whatsappEnabled">Add WhatsApp Number</label>
                <input
                  type="checkbox"
                  id="whatsappEnabled"
                  checked={whatsappEnabled}
                  onChange={() => {
                    setWhatsappEnabled(!whatsappEnabled);
                    setFormData({ ...formData, whatsappNumber: "" });
                  }}
                />
              </div>

              {whatsappEnabled && (
                <div>
                  <label htmlFor="whatsappNumber">WhatsApp Number:</label>
                  <input
                    type="text"
                    name="whatsappNumber"
                    maxLength={10}
                    pattern="[6-9][0-9]{9}"
                    title="Only valid 10-digit Indian numbers"
                    id="whatsappNumber"
                    onKeyPress={handleKeyPressNumber}
                    value={formData.whatsappNumber}
                    onChange={handleInputChange}
                  />
                  {errors.whatsappNumber && (
                    <p className="error">{errors.whatsappNumber}</p>
                  )}
                </div>
              )}

              <button type="submit">
                <FontAwesomeIcon icon={faPaperPlane} /> Submit
              </button>
              <button className="closebtn" onClick={() => setShowForm(false)}>
                <FontAwesomeIcon icon={faXmark} /> Close
              </button>
            </form>
          </div>
        </div>
      )}

      {showSmsPopup && currentCustomer && (
        <div className="popup">
          <div className="popup-content">
            <h3>Send SMS to {currentCustomer.name}</h3>
            <textarea
              value={smsContent}
              maxLength={160}
              onChange={(e) => setSmsContent(e.target.value)}
              placeholder="Enter SMS content (max 160 characters)"
            ></textarea>
            {smsErrors.smsContent && (
              <p className="error">{smsErrors.smsContent}</p>
            )}
            <button onClick={handleSms}>Send SMS</button>
            <button className="closebtn" onClick={() => setShowSmsPopup(false)}>
              <FontAwesomeIcon icon={faXmark} /> Close
            </button>
          </div>
        </div>
      )}

      {showPolicyPopup && (
        <div
          className="popup-overlay"
          onClick={() => setShowPolicyPopup(false)}
        >
          <div className="popup-content" onClick={(e) => e.stopPropagation()}>
            <button
              className="close-button"
              onClick={() => setShowPolicyPopup(false)}
            >
              &times; {/* Close button */}
            </button>
            <h2>Policy Details</h2>
            <div className="policy-details">
              {customerPolicyDetails.length > 0 ? (
                customerPolicyDetails.map((policy, index) => (
                  <div key={index} className="policy-card">
                    <p>
                      <strong>Policy:</strong> {policy.policy}
                    </p>
                    <p>
                      <strong>Status:</strong> {policy.status}
                    </p>
                    <p>
                      <strong>Policy Number:</strong> {policy.policyNumber}
                    </p>
                    <p>
                      <strong>Starting Date:</strong>{" "}
                      {new Date(policy.startingDate).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>Renewal Date:</strong>{" "}
                      {new Date(policy.DOB).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>Amount Paid:</strong> ₹ {policy.amountPaid}
                    </p>
                    <p style={{ overflowWrap: "break-word" }}>
                      <strong>Description:</strong> {policy.description}
                    </p>
                  </div>
                ))
              ) : (
                <p>No policy data available.</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneralUsersList;
