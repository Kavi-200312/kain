import React, { useState, useEffect } from "react";
import axiosInstance from "../../../Utils/axiosInstance";
import styles from './Policies.module.css';

export default function Policies() {
  const [pipelineData, setPipelineData] = useState([]);
  const [showPolicyDocument, setShowPolicyDocument] = useState(false);
  const [currentDocument, setCurrentDocument] = useState(null);
  const [error, setError] = useState(null);
  const [documentBase64, setDocumentBase64] = useState(null);

  // Fetch pipeline data when the component mounts
  useEffect(() => {
    const fetchPipelineData = async () => {
      try {
        const response = await axiosInstance.get("/ins/getPolicyDetails");
        setPipelineData(response.data.data);
        // console.log(response.data.data);
      } catch (error) {
        console.error("Error fetching pipeline data:", error);
        setError("Failed to load policy data. Please try again later.");
      }
    };

    fetchPipelineData();
  }, []);

  // Convert the buffer (ArrayBuffer, Uint8Array, Buffer) to Base64
  const convertBufferToBase64 = (bufferData) => {
    try {
      // Ensure bufferData is in the correct type (ArrayBuffer or Uint8Array)
      let arrayBuffer;

      // If data is already an ArrayBuffer, use it directly
      if (bufferData instanceof ArrayBuffer) {
        arrayBuffer = bufferData;
      }
      // If data is Uint8Array, convert it to ArrayBuffer
      else if (bufferData instanceof Uint8Array) {
        arrayBuffer = bufferData.buffer;
      }
      // If it's a Buffer (Node.js), we need to convert it into a Uint8Array
      else if (bufferData.data && Array.isArray(bufferData.data)) {
        arrayBuffer = new Uint8Array(bufferData.data).buffer;
      } else {
        console.error("Invalid buffer data type. Expected ArrayBuffer or Uint8Array.");
        return null;
      }

      const sizeLimit = 100 * 1024; // 100 KB limit for direct Base64 encoding

      // If the file is too large, use FileReader for larger files
      if (arrayBuffer.byteLength > sizeLimit) {
        // console.warn("File too large for direct btoa conversion. Using FileReader.");

        const blob = new Blob([arrayBuffer], { type: bufferData.type });
        const reader = new FileReader();

        // Return a Promise for asynchronous operation
        return new Promise((resolve, reject) => {
          reader.onloadend = () => {
            resolve(reader.result);  // Base64 result from FileReader
          };
          reader.onerror = reject;

          reader.readAsDataURL(blob); // Convert Blob to Base64 using FileReader
        });
      } else {
        // For smaller files, use btoa (Base64 encoding)
        const base64String = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
        return `data:image/${bufferData.type.split('/')[1]};base64,${base64String}`;
      }
    } catch (error) {
      console.error("Error converting buffer to Base64:", error);
      return null;
    }
  };

  // Group the policy data by policy name
  const groupedByPolicy = pipelineData.reduce((acc, item) => {
    if (item.policy) {
      if (!acc[item.policy]) {
        acc[item.policy] = [];
      }
      acc[item.policy].push(item);
    }
    return acc;
  }, {});

  // Handle the document click and set the document for preview
  const handleDocumentClick = (document) => {
    if (document && document.data) {
      setCurrentDocument(document);
      setShowPolicyDocument(true);
    } else {
      console.error("Invalid document data");
    }
  };

  // Convert document to Base64 once the document is set
  useEffect(() => {
    if (currentDocument) {
      // console.log('Converting document:', currentDocument);
      const convertDocumentToBase64 = async () => {
        const base64Data = await convertBufferToBase64(currentDocument);  // Await for Base64 result
        setDocumentBase64(base64Data);  // Set the Base64 string in state
      };

      convertDocumentToBase64();
    }
  }, [currentDocument]);  // Re-run when currentDocument changes

  // Close the modal for document preview
  const closeModal = () => {
    setShowPolicyDocument(false);
    setCurrentDocument(null);
    setDocumentBase64(null);  // Clear Base64 when closing modal
  };

  return (
    <div className={styles['pipeline-crm']}>
      <h2>Policy Details</h2>

      {/* Display error message if there is an error */}
      {error && <div className={styles['error-message']}>{error}</div>}

      {/* Render each policy category */}
      {Object.keys(groupedByPolicy).map((policy) => (
        <div key={policy} className={styles['policy-category']}>
          <h3>{policy}</h3>
          <div className={styles['policy-cards']}>
            {groupedByPolicy[policy].map((item, index) => (
              <div key={index} className={styles['policy-card']}>
                <h4>Customer: {item.customerName}</h4>
                <p><b>Referred By:</b> {item.referredBy}</p>
                <p style={{overflowWrap: "break-word"}}><b>Description:</b>{item.description}</p>
                <p><b>Status:</b> {item.status}</p>
                <p><b>Policy Number:</b> {item.policyNumber}</p>
                <p><b>Starting Date:</b> <span className={styles['date']}>{new Date(item.startingDate).toLocaleDateString()}</span></p>
                <p><b>Ending Date:</b> <span className={styles['date']}>{new Date(item.endingDate).toLocaleDateString()}</span></p>
                <p><b>Date of birth:</b> <span className={styles['date']}>{new Date(item.DOB).toLocaleDateString()}</span></p>
                <p><b>Amount Paid:</b> <span className={styles['amount']}>₹ {item.amountPaid}</span></p>
                <p><b>Biller Name:</b> {item.billerName}</p>

                {/* Check if document exists and render a clickable span */}
                {item.document && (
                  <div className={styles['document-preview']}>
                    <b>Document:</b>
                    <span
                      className={styles['click-to-open']}
                      onClick={() => handleDocumentClick(item.document)}
                    >
                      Open file
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Modal for displaying the document */}
      {showPolicyDocument && currentDocument && (
        <div className={styles['popup-overlay']} onClick={closeModal}>
          <div className={styles['popup-content']} onClick={(e) => e.stopPropagation()}>
            <button className={styles['close-button']} onClick={closeModal}>&times;</button>
            <h4>Document Preview</h4>
            {/* Only try to convert and display the image if there's a valid document */}
            {documentBase64 ? (
              <img
                src={documentBase64}  // Use the Base64 string stored in state
                alt="Document preview"
                className={styles['document-image']}
                width="700"  // Set the width of the image (you can adjust)
                height="auto"
              />
            ) : (
              <div className={styles['error-message']}>Error loading document preview.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

