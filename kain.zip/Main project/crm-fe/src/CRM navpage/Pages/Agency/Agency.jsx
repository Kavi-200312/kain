import React, { useState } from 'react'
import stylesAgency from './Agency.module.css'
import axiosInstance from '../../../Utils/axiosInstance'
import { ToastContainer, toast } from 'react-toastify'

export default function Agency() {
  const [selectedAgency, setSelectedAgency] = useState('')
  const [formData, setFormData] = useState({
    customerName: '',
    policyNumber: '',
    dob: ''
  })
  const [errors, setErrors] = useState({})  

  const handleAgencyChange = (e) => {
    setSelectedAgency(e.target.value)
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }))
  }


  const validateForm = () => {
    const newErrors = {};
  
    // Validate Customer Name
    if (formData.customerName.length < 3 || formData.customerName.length > 35) {
      newErrors.customerName = 'Customer name must be between 3 and 35 characters.';
    }
  
  if (formData.dob) {
    const dob = new Date(formData.dob);
    const currentDate = new Date();

    // Create separate copies for min and max age calculations
    const minAgeDate = new Date(currentDate);
    const maxAgeDate = new Date(currentDate);

    // Set the minAgeDate to 65 years ago and maxAgeDate to 18 years ago
    minAgeDate.setFullYear(currentDate.getFullYear() - 65);
    maxAgeDate.setFullYear(currentDate.getFullYear() - 18);

    // Check if the DOB is within the 18-65 years range
    if (dob > maxAgeDate || dob < minAgeDate) {
      newErrors.dob = 'Customer age must be between 18 and 65 years old.';
    }
  }
  
    // Validate Policy Number (must be numeric and 8-10 digits)
    if (!/^\d{8,10}$/.test(formData.policyNumber)) {
      newErrors.policyNumber = 'Policy number must be a number and between 8 to 10 digits.';
    }
  
    return newErrors;
  };
  
  const handleKeyPressNumber = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if (charCode < 48 || charCode > 57) {
      e.preventDefault(); 
    }
  };

  const handleKeyPressString = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
      e.preventDefault(); 
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault() 
    const agency = {...formData,selectedAgency:selectedAgency}
    // console.log(agency);

    const validationErrors = validateForm()
    setErrors(validationErrors)

    if (Object.keys(validationErrors).length > 0) {
      return
    }
    // console.log('Form Data:', formData)

    try {
    const response = await axiosInstance.post('/ins/customerDetailsRenewAgency',agency)
    setFormData({
      customerName: '',
      policyNumber: '',
      dob: ''
    })
    if(response.status===201){
      toast.success(response.data.message)
      // alert(response.data.message)
    }
      
    } catch (error) {
      // console.log(error.message , "api can't call ")
      toast.error(error.message)
    }
  }

  return (
    <div className={stylesAgency.main_div}>
      <ToastContainer/>
      <div>
        <h1 className={stylesAgency.h1}>Supported Agency</h1>
              
              <select name="insuranceAgency" onChange={handleAgencyChange} className={stylesAgency.select}>
          <option disabled selected={!selectedAgency } className={stylesAgency.option}>
            Select Agency
          </option>
          <option value="HDFC">HDFC Lombard</option>
          <option value="ICIC">ICIC</option>
          <option value="SIB">SIB</option>
          <option value="LIC">LIC</option>
        </select>
      </div>

      {/* Conditionally render the form based on the selected agency */}
      {selectedAgency && (
        <form className={stylesAgency.form} onSubmit={handleSubmit}>
          <div>
            <label htmlFor="customerName" className={stylesAgency.label}>Customer Name</label>
            <input
              type="text"
              id="customerName"
              name="customerName"
              minLength={3}
              maxLength={35}
              className={stylesAgency.inputC}
              onKeyPress={handleKeyPressString}
              value={formData.customerName}
              onChange={handleInputChange}
              required
            />
            {errors.customerName && <p className={stylesAgency.error}>{errors.customerName}</p>}
          </div>
          <div>
            <label htmlFor="policyNumber">Policy Number</label>
            <input
              type="text"
              id="policyNumber"
              name="policyNumber"
              className={stylesAgency.inputC}
              onKeyPress={handleKeyPressNumber}
              minLength={8}
              maxLength={10}
              value={formData.policyNumber}
              onChange={handleInputChange}
              required
            />
            {errors.policyNumber && <p className={stylesAgency.error}>{errors.policyNumber}</p>}
          </div>

          {/* If HDFC or LIC is selected, show Date of Birth field */}
          {(selectedAgency === 'HDFC' || selectedAgency === 'LIC') && (
            <div>
              <label htmlFor="dob">Date of Birth</label>
              <input
                type="date"
                id="dob"
                name="dob"
                value={formData.dob}
              className={stylesAgency.inputC}
                onChange={handleInputChange}
                required
              />
              {errors.dob && <p className={stylesAgency.error}>{errors.dob}</p>}
            </div>
          )}

          <button type="submit" className={stylesAgency.button}>Bill</button>
        </form>
      )}
    </div>
  )
}
