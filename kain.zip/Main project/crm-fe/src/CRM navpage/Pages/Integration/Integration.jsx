import React, { useState } from "react";
import styles from "./Integration.module.css";
import axiosInstance from "../../../Utils/axiosInstance";
import { ToastContainer, toast } from "react-toastify";

const Integration = () => {
  const [amount, setAmount] = useState("");
  const [isPopupVisible, setIsPopupVisible] = useState(false);

  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (value === "" || !isNaN(value)) {
      setAmount(value); // Update state when input changes
    }
  };
  const handleKeyPressNumber = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if (charCode < 48 || charCode > 57) {
      e.preventDefault();
    }
  };

  const handlePayClick = async () => {
    try {
      if (!amount || amount <= 0) {
        toast.error("Please enter a valid amount", { autoClose: 3000 });
        return;
      }
  
      // console.log("Paying amount:", amount);
  
      // Send the amount in the correct format (assuming the backend expects an object)
      const response = await axiosInstance.post('/ins/paymentProcess', { amount });
  
      // Handle different response statuses
      if (response.status === 200) {
        toast.success("Payment successfully completed!", { autoClose: 3000 });
        setAmount(""); // Reset amount only on success
      } else if (response.status === 400) {
        toast.error("Invalid payment request. Please check the amount.", { autoClose: 3000 });
      } else if (response.status === 500) {
        toast.error("Server error. Please try again later.", { autoClose: 3000 });
      }
  
      // Close the popup regardless of success or failure
      setIsPopupVisible(false);
  
    } catch (error) {
      // console.log(error); // Log the error for debugging
  
      // Display a user-friendly error message
      toast.error("Payment failed. Please try again.", { autoClose: 3000 });
      
      // Optionally, you can check if the error is a network or server error
      if (error.response) {
        // Server returned an error (e.g., 400, 500)
        // console.log("Response error:", error.response);
      } else if (error.request) {
        // No response received (network issue)
        // console.log("Request error:", error.request);
      } else {
        // Other error (e.g., configuration error)
        // console.log("Error:", error.message);
      }
    }
  };
  

  const handleAddClick = () => {
    setIsPopupVisible(true); // Show the popup when "Add" is clicked
  };
  const showAgencyandPayments = () => {};
  const hideAgencyandPayments = () => {};

  return (
    <div className={styles.mainIntegration}>
      <ToastContainer />
      <div className={styles.walletDiv}>
        <div className={styles.addButton} onClick={handleAddClick}>
          Wallet
        </div>
      </div>
      <div className={styles.integration}>
        <div className={styles.zustpe_directory}>
          <p>zustpe Directory</p>
          <div className={styles.button}>
            <div className={styles.enable}>Enable</div>
            <div className={styles.disable}>Disable</div>
          </div>
        </div>
        <div className={styles.zustpe_communication}>
          <p>zustpe Communication</p>
          <div className={styles.button}>
            <div className={styles.enable}>Enable</div>
            <div className={styles.disable}>Disable</div>
          </div>
        </div>
        <div className={styles.zustpe_payments}>
          <p>zustpe Payments</p>
          <div className={styles.button}>
            <div className={styles.enable} onClick={showAgencyandPayments}>
              Enable
            </div>
            <div className={styles.disable} onClick={hideAgencyandPayments}>
              Disable
            </div>
          </div>
        </div>
      </div>

      {/* Wallet Popup */}
      {isPopupVisible && (
        <>
          <div
            className={`${styles.walletOverlay} ${
              isPopupVisible ? styles.show : ""
            }`}
            onClick={() => setIsPopupVisible(false)}
          />
          <div
            className={`${styles.walletPopup} ${
              isPopupVisible ? styles.show : ""
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <p>Add amount</p>
            <input
              type="text"
              maxLength={7}
              onKeyPress={handleKeyPressNumber}
              value={amount}
              onChange={handleAmountChange}
              placeholder="Enter amount"
              required
            />
            <div className={styles.button}>
              <button onClick={handlePayClick}>Pay</button>
              <button onClick={() => setIsPopupVisible(false)}>close</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Integration;
