import React, { useState, useEffect } from "react";
import "./Pipeline.css";
import axiosInstance from "../../../Utils/axiosInstance";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBarsStaggered, faUserPlus } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";

const Pipeline = () => {
  const navigate = useNavigate();
  const [CustomerListName, setCustomerListName] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/");
    }
  }, [navigate]);


  useEffect(() => {
    const fetchCustomerName = async () => {
      try {
        const response = await axiosInstance.get("/ins/getCustomers");
        setCustomerListName(response.data.data);
        
        // Check for 401 error in the response
        if (response.data.code === 401) {
          localStorage.removeItem("token");
          localStorage.removeItem("hash");
          alert(response.data.message);
          navigate("/"); // Assuming navigate is from react-router
        }
      } catch (error) {
        // Check if error.response is defined and handle the error appropriately
        if (error.response && error.response.data) {
          if (error.response.data.code === 401) {
            localStorage.removeItem("token");
            localStorage.removeItem("hash");
            navigate("/"); // Redirect to login page
          } else {
            alert(error.response.data.message || "An error occurred");
          }
        } else {
          // This handles cases where error.response is undefined
          // console.log("Network error or server is unavailable");
        }
      }
    };

    fetchCustomerName();
  }, []);


  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [formData, setFormData] = useState({
    customerName: "",
    referredBy: "",
    description: "",
    status: "",
  });
  const [pipelineData, setPipelineData] = useState([]);
  const [errors, setErrors] = useState({
    customerName: "",
    referredBy: "",
    description: "",
  });

  const [isClosedPopupOpen, setIsClosedPopupOpen] = useState(false);

  const [closedFormData, setClosedFormData] = useState({
    policy: "",
    billerName: "",
    policyNumber: "",
    startingDate: "",
    DOB: "",
    amountPaid: "",
    document: null,
    customerName: "",
    referredBy: "",
    description: "",
    status: "Closed",
  });
  const [closedFormErrors, setClosedFormErrors] = useState({
    policy: "",
    billerName: "",
    policyNumber: "",
    startingDate: "",
    DOB: "",
    amountPaid: "",
    document: "",
  });

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "customerName" && value) {
      const [customerName, contactNumber] = value.split("-");

      setFormData({
        ...formData,
        customerName: customerName,
        contactNumber: contactNumber,
      });
      // console.log(formData.customerName,formData.contactNumber)
    } else {
      setFormData({ ...formData, [name]: value });
    }

    if (name === "referredBy") {
      if (!/^[A-Za-z\s]*$/.test(value)) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          referredBy: "Only letters and spaces allowed.",
        }));
      } else {
        setErrors((prevErrors) => ({ ...prevErrors, referredBy: "" }));
      }
    }

    if (name === "description") {
      if (value.length > 160) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          description: "Description cannot exceed 160 characters.",
        }));
      } else {
        setErrors((prevErrors) => ({ ...prevErrors, description: "" }));
      }
    }
  };

  const handleClosedFormInputChange = (e) => {
    const { name, value, type, files } = e.target;
 
    const file = files && files[0]; // Ensure the 'files' array exists and has at least one file
    // console.log(file); // Log the file to verify
  
    if (file) {
      const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB in bytes
  
      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        // File size exceeds 2MB
        setClosedFormErrors((prev) => ({
          ...prev,
          document: "File size must be less than 2MB",
        }));
      } else {
        // Reset error message if file size is valid
        setClosedFormErrors((prev) => ({
          ...prev,
          document: "",
        }));
      }
    } 

    setClosedFormData({
      ...closedFormData,
      [name]: type === "file" ? files[0] : value,
    });

    if (name === "billerName" && !/^[A-Za-z\s]*$/.test(value)) {
      setClosedFormErrors((prev) => ({
        ...prev,
        billerName: "Only letters and spaces are allowed for Biller Name.",
      }));
    } else {
      setClosedFormErrors((prev) => ({ ...prev, billerName: "" }));
    }

    // Validation for Policy Number (only numbers allowed)
    if (name === "policyNumber" && !/^\d+$/.test(value)) {
      setClosedFormErrors((prev) => ({
        ...prev,
        policyNumber: "Only numbers are allowed for Policy Number.",
      }));
    } else {
      setClosedFormErrors((prev) => ({ ...prev, policyNumber: "" }));
    }

    // Amount Paid Validation (only digits)
    if (name === "amountPaid") {
      if (!/^\d+(\.\d{1,2})?$/.test(value)) {
        setClosedFormErrors((prev) => ({
          ...prev,
          amountPaid: "Only valid numeric values are allowed for Amount Paid.",
        }));
      } else {
        setClosedFormErrors((prev) => ({ ...prev, amountPaid: "" }));
      }
    }

    // Validate DOB if the input name is "DOB"
    if (name === "DOB") {
        const diffMs = Date.now() - new Date(value).getTime();
        const ageDate = new Date(diffMs);
        const age =  Math.abs(ageDate.getUTCFullYear() - 1970);
    
      if (age < 18 || age > 65) {
        setClosedFormErrors({
          ...closedFormErrors,
          DOB: "Customer must be between 18 and 65 years old.",
        });
      } else {
        // Clear the error message if the age is valid
        setClosedFormErrors({
          ...closedFormErrors,
          DOB: "",
        });
      }
    }

    if (name === "startingDate") {
      if (value && new Date(value) < new Date()) {
        setClosedFormErrors((prev) => ({
          ...prev,
          startingDate: "Starting date cannot be later than the today date.",
        }));
      } else {
        setClosedFormErrors((prev) => ({ ...prev, startingDate: "" }));
      }
    }
    if (name === "endingDate") {
      // Ensure the ending date is not before today
      if (value && new Date(value) < new Date()) {
        setClosedFormErrors((prev) => ({
          ...prev,
          endingDate: "Ending date cannot be earlier than today.",
        }));
      }
      // Ensure ending date is after starting date
      else if (value && new Date(value) < new Date(closedFormData.startingDate)) {
        setClosedFormErrors((prev) => ({
          ...prev,
          endingDate: "Ending date cannot be earlier than the starting date.",
        }));
      }
      // Ensure ending date is within the allowed range
      else if (value && (new Date(value) < new Date(new Date().setFullYear(new Date().getFullYear() + 1)) || new Date(value) > new Date(new Date().setFullYear(new Date().getFullYear() + 50)))) {
        setClosedFormErrors((prev) => ({
          ...prev,
          endingDate: "Ending date must be between 1 year from today and 50 years from today.",
        }));
      }
      // No errors, clear the ending date error
      else {
        setClosedFormErrors((prev) => ({ ...prev, endingDate: "" }));
      }
    }
    

  };

  const handleKeyPressNumber = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if (charCode < 48 || charCode > 57) {
      e.preventDefault();
    }
  };

  const handleKeyPressString = (e) => {
    const charCode = e.charCode ? e.charCode : e.keyCode;
    if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
      e.preventDefault();
    }
  };

  useEffect(() => {
    const fetchPipelineData = async () => {
      try {
        const response = await axiosInstance.get("/ins/getpipeline");
        setPipelineData(response.data.data);
      } catch (error) {
        // Check if error.response is defined and handle the error appropriately
        if (error.response && error.response.data) {
          if (error.response.data.code === 401) {
            localStorage.removeItem("token");
            localStorage.removeItem("hash");
            navigate("/"); // Redirect to login page
          } else {
            alert(error.response.data.message || "An error occurred");
          }
        } else {
          // This handles cases where error.response is undefined
          // console.log("Network error or server is unavailable");
        }
      }
      
    };
    fetchPipelineData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (errors.customerName || errors.referredBy || errors.description) {
      return;
    }

    try {
      const response = await axiosInstance.post("/ins/addpipeline", formData);
      setPipelineData([...pipelineData, response.data.data]);
      setFormData({
        customerName: "",
        contactNumber: "",
        referredBy: "",
        description: "",
        status: "",
      });
      closePopup();
    } catch (error) {
      if (error.response.data.code === 401) {
        localStorage.removeItem("token");
        navigate("/");
      }
      console.error("Failed to add pipeline data:", error);
    }
  };

  const handleClosedFormSubmit = async (e) => {
    e.preventDefault();

    // Check if there are any validation errors in closedFormErrors
    if (Object.values(closedFormErrors).some((error) => error !== "")) {
      return; // If there are validation errors, prevent form submission
    }



    try {
      // Prepare FormData
      const formData = new FormData();

      // Append all form fields
      formData.append("customerName", closedFormData.customerName);
      formData.append("referredBy", closedFormData.referredBy);
      formData.append("description", closedFormData.description);
      formData.append("status", "Closed"); // Ensure the status is set to "Closed"
      formData.append("policy", closedFormData.policy); // Append policy field
      formData.append("billerName", closedFormData.billerName);
      formData.append("policyNumber", closedFormData.policyNumber);
      formData.append("startingDate", closedFormData.startingDate);
      formData.append("endingDate", closedFormData.endingDate);
      formData.append("DOB", closedFormData.DOB);
      formData.append("amountPaid", closedFormData.amountPaid);

      // If a document is selected, append the file
      if (closedFormData.document) {
        formData.append("document", closedFormData.document);
      }



      // Make the API call to update the pipeline
      const response = await axiosInstance.put(
        "/ins/updatepipeline",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data", // Ensure proper content type for FormData
          },
        }
      );

      // Update pipelineData with the new data
      setPipelineData(
        pipelineData.map((data) =>
          data.customerName === closedFormData.customerName &&
          data.referredBy === closedFormData.referredBy &&
          data.description === closedFormData.description
            ? { ...data, status: "Closed", ...closedFormData }
            : data
        )
      );

      // Close the popup and reset the form data
      setIsClosedPopupOpen(false);
      setClosedFormData({
        policy: "",
        billerName: "",
        policyNumber: "",
        startingDate: "",
        DOB: "",
        amountPaid: "",
        document: null,
      });
      toast.success(` ${closedFormData.customerName} polciy status closed`, { autoClose: 3000 });

    } catch (error) {
      // Handle the error gracefully
      console.error("Failed to update pipeline with closed details:", error);
      toast.error("Something went wrong")
      if (error.response && error.response.data) {
        console.error("Error message:", error.response.data.message);
      }
    }
  };

  // const onDragEnd = async (result) => {
  //   const { source, destination, draggableId } = result;

  //   if (!destination) return;
  //   if (source.droppableId === destination.droppableId) return;

  //   const [customerName, referredBy, description] = draggableId.split("-");

  //   const item = pipelineData.find(
  //     (data) =>
  //       data.customerName === customerName &&
  //       data.referredBy === referredBy &&
  //       data.description === description
  //   );

  //   if (!item) return;

  //   if (destination.droppableId === "Closed") {
  //     setClosedFormData({
  //       ...closedFormData,
  //       customerName: item.customerName,
  //       referredBy: item.referredBy,
  //       description: item.description,
  //       status: "Closed",
  //     });
  //     setIsClosedPopupOpen(true);
  //     return;
  //   }

  //   const updatedData = pipelineData.map((data) =>
  //     data.customerName === item.customerName &&
  //     data.referredBy === item.referredBy &&
  //     data.description === item.description
  //       ? { ...data, status: destination.droppableId }
  //       : data
  //   );
  //   setPipelineData(updatedData);

  //   try {
  //     await axiosInstance.put(`/ins/updatepipeline`, {
  //       customerName: item.customerName,
  //       referredBy: item.referredBy,
  //       description: item.description,
  //       status: destination.droppableId,
  //     });
  //     // console.log("Status updated successfully");
  //   } catch (error) {
  //     console.error("Failed to update pipeline data:", error);
  //   }
  // };

  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;

    if (!destination) return; // Dropped outside any droppable area
    if (source.droppableId === destination.droppableId) return; // No change if dropped in the same column

    const [customerName, referredBy, description] = draggableId.split("-");

    const item = pipelineData.find(
      (data) =>
        data.customerName === customerName &&
        data.referredBy === referredBy &&
        data.description === description
    );

    if (!item) return; // Item not found

    // Handle "Closed" status separately for opening the form
    if (destination.droppableId === 'Closed') {
      // Remove the item from the pipelineData when it reaches "Closed" status
      const updatedData = pipelineData.filter(
        (data) => data.customerName !== item.customerName || data.referredBy !== item.referredBy || data.description !== item.description
      );

      setPipelineData(updatedData);

      // Show the "Closed" form for entering policy details
      setClosedFormData({
        ...closedFormData,
        customerName: item.customerName,
        referredBy: item.referredBy,
        description: item.description,
        status: 'Closed',
      });
      setIsClosedPopupOpen(true);
      return;
    }

    // Update the pipeline data with the new status
    const updatedData = pipelineData.map((data) =>
      data.customerName === item.customerName &&
      data.referredBy === item.referredBy &&
      data.description === item.description
        ? { ...data, status: destination.droppableId }
        : data
    );

    setPipelineData(updatedData);

    try {
      await axiosInstance.put(`/ins/updatepipeline`, {
        customerName: item.customerName,
        referredBy: item.referredBy,
        description: item.description,
        status: destination.droppableId,
      });
    } catch (error) {
      console.error("Failed to update pipeline data:", error);
    }
  };



  const groupedData = pipelineData.reduce((acc, item) => {
    const status = item.status || "Referral";
    if (!acc[status]) acc[status] = [];
    acc[status].push(item);
    return acc;
  }, {});

  const statuses = ["Referral", "Lead", "In Discussion", "Customer", "Closed"];



  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="pipeline-crm">
      <ToastContainer />
        <h2>
          <FontAwesomeIcon
            style={{ color: "green", fontSize: "25px" }}
            icon={faBarsStaggered}
          />{" "}
          Pipeline Details
        </h2>
        <div className="crm_pipeline_form">
          <button onClick={openPopup}>
            <FontAwesomeIcon icon={faUserPlus} /> Add
          </button>
        </div>
        <br />
        <table>
          <thead>
            <tr>
              {statuses.map((status) => (
                <th key={status}>{status}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              {statuses.map((status) => (
                <Droppable droppableId={status} key={status}>
                  {(provided) => (
                    <td
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className="status-column"
                    >
                      {groupedData[status]?.length > 0 ? (
                        groupedData[status].map((item, index) => (
                          <Draggable
                            key={
                              item.customerName +
                              item.referredBy +
                              item.description
                            }
                            draggableId={`${item.customerName}-${item.referredBy}-${item.description}`}
                            index={index}
                          >
                            {(provided) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className="card_pipeline"
                                // style={{overflow:"hidden"}}
                              >
                                <span>
                                  <b>Name: </b>
                                  {item.customerName}
                                </span>
                                <br />
                                <span>
                                  <b>Referred By: </b>
                                  {item.referredBy}
                                </span>
                                <br />
                                <span>
                                  <b title={item.description}>Description</b>
                                </span>
                                <br />
                                <span>
                                  <b>Status: </b>
                                  {item.status}
                                </span>
                              </div>
                            )}
                          </Draggable>
                        ))
                      ) : (
                        <div className="no-data-message">No data available</div>
                      )}
                      {provided.placeholder}
                    </td>
                  )}
                </Droppable>
              ))}
            </tr>
          </tbody>
        </table>

        {/* Add Pipeline Form */}
        {isPopupOpen && (
          <div className="popup" onClick={closePopup}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h3>Add Pipeline Details</h3>
              <form onSubmit={handleSubmit} autoComplete="off">
                <div className="select-dropdown">
                  <label>
                    Customer Name:
                    <input
                      name="customerName"
                      value={formData.customerName}
                      onChange={handleInputChange}
                      required
                      list="customerNameList"
                    />
                      
                      <datalist id="customerNameList">
                      {CustomerListName.map((customer, index) => (
                        <option
                          key={index}
                          value={`${customer.name}-${customer.contactNumber}`}
                        >
                          {" "}
                          
                          {customer.name} ({customer.contactNumber}){" "}
                        </option>
                      ))}
                      </datalist>
                    
                  </label>
                  {formData.customerName && (
                    <div style={{ fontSize: "12px", color: "gray" }}>
                      Selected Customer: {formData.customerName}{" "}
                    </div>
                  )}
                </div>

                <label>
                  Referred By:
                  <input
                    type="text"
                    name="referredBy"
                    maxLength={25}
                    minLength={3}
                    value={formData.referredBy}
                    onChange={handleInputChange}
                    required
                  />
                  {errors.referredBy && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {errors.referredBy}
                    </span>
                  )}
                </label>
                <label>
                    Status:
                    <select
                      id="status"
                      name="status"
                      onChange={handleInputChange}
                      required
                      value={formData.status}
                      // style={{color:"black"}}
                    >
                      <option value="" disabled>
                        Select a Status
                      </option>
                      <option value="Referral">Referral</option>
                      <option value="Lead">Lead</option>
                      <option value="In Discussion">In Discussion</option>
                      <option value="Customer">Customer</option>
                    </select>
                  </label>
                <label>
                  Description:
                  <textarea
                    name="description"
                    maxLength={160}
                    value={formData.description}
                    onChange={handleInputChange}
                    required
                  />
                  {errors.description && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {errors.description}
                    </span>
                  )}
                </label>
                <button type="submit">Add Pipeline</button>
                <button type="button" onClick={closePopup}>
                  Close
                </button>
              </form>
            </div>
          </div>
        )}

        {isClosedPopupOpen && (
          <div className="popup"  onClick={() => setIsClosedPopupOpen(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h3>Closed Pipeline Details</h3>
              <form
                onSubmit={handleClosedFormSubmit}
                encType="multipart/form-data"
                autoComplete="off"
              >
                <div className="container">
                  <label>
                    Select a Policy:
                    <select
                      id="policy"
                      name="policy"
                      onChange={handleClosedFormInputChange}
                      required
                      value={closedFormData.policy}
                    >
                      <option value="" disabled>
                        Select a policy
                      </option>
                      <option value="Health">Health</option>
                      <option value="Life">Life</option>
                      <option value="Travel">Travel</option>
                      <option value="Auto">Auto</option>
                    </select>
                  </label>
                </div>

                <label>
                  Biller Name:
                  <input
                    type="text"
                    name="billerName"
                    maxLength={25}
                    minLength={3}
                    onKeyPress={handleKeyPressString}
                    value={closedFormData.billerName}
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.billerName && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.billerName}
                    </span>
                  )}
                </label>

                <label>
                  Policy Number:
                  <input
                    type="text"
                    name="policyNumber"
                    maxLength={10}
                    minLength={8}
                    onKeyPress={handleKeyPressNumber}
                    value={closedFormData.policyNumber}
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.policyNumber && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.policyNumber}
                    </span>
                  )}
                </label>

                <label>
                  Starting Date:
                  <input
                    type="date"
                    name="startingDate"
                    defaultValue={closedFormData.startingDate}
                    min={new Date().toISOString().split("T")[0]}
                    max={
                      new Date(
                        new Date().setFullYear(new Date().getFullYear() + 1)
                      )
                        .toISOString()
                        .split("T")[0]
                    }
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.startingDate && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.startingDate}
                    </span>
                  )}
                </label>

                
                <label>
                  End Date:
                  <input
                    type="date"
                    name="endingDate"
                    // defaultValue={closedFormData.startingDate}
                    // min={new Date().toISOString().split("T")[0]}
                    min={
                      new Date(
                        new Date().setFullYear(new Date().getFullYear() + 1)
                      )
                        .toISOString()
                        .split("T")[0]
                    }
                    max={
                      new Date(
                        new Date().setFullYear(new Date().getFullYear() + 75)
                      )
                        .toISOString()
                        .split("T")[0]
                    }
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.endingDate && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.endingDate}
                    </span>
                  )}
                </label>

                <label>
                  Date of birth:
                  <input
                    type="date"
                    name="DOB"
                    value={closedFormData.DOB}
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.DOB && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.DOB}
                    </span>
                  )}
                </label>

                <label>
                  Amount Paid:
                  <input
                    type="text"
                    name="amountPaid"
                    maxLength={7}
                    onKeyPress={handleKeyPressNumber}
                    value={closedFormData.amountPaid}
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.amountPaid && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.amountPaid}
                    </span>
                  )}
                </label>

                <label>
                  Document:
                  <input
                    type="file"
                    name="document"
                    onChange={handleClosedFormInputChange}
                    required
                  />
                  {closedFormErrors.document && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {closedFormErrors.document}
                    </span>
                  )}
                </label>

                <button type="submit">Save Details</button>
                <button
                  type="button"
                  onClick={() => setIsClosedPopupOpen(false)}
                >
                  Close
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </DragDropContext>
  );



};

export default Pipeline;
