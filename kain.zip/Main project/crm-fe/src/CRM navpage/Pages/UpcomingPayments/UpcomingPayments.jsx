import React, { useEffect, useState } from 'react'
import style from './UpcomingPayments.module.css'
import axiosInstance from '../../../Utils/axiosInstance'
import { useNavigate } from 'react-router-dom';

export default function UpcomingPayments() {
  const [billDetails,setBillDetails] = useState([])
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axiosInstance.get('/ins/upcomingpayments');
        
        // Check if response and response.data are valid
        if (response && response.data) {
          setBillDetails(response.data.data);
          
          // Check if 'code' exists in the response data
          if (response.data.code === 401) {
            localStorage.removeItem("token");
            localStorage.removeItem("hash");
            alert(response.data.message);
            navigate("/");
          }
        } else {
          // console.log('Invalid response data:', response);
          setBillDetails(null);  // Set state to null or empty array if response is invalid
        }
      } catch (error) {
        // console.log("Can't get data", error.message);
        setBillDetails(null);
      }
    };
  
    fetchData(); // Call the async function
  }, []);
  
  return (
    <div className={style.main_div}>
      <h1>Upcoming Payments</h1>
      <table>
        <thead>
          <th>Customer Name</th>
          <th>Policy Number</th>
          <th>Renewal Date</th>
          <th>Bill Amount</th>
          <th>pay</th>
        </thead>
        <tbody>
            {billDetails ? (billDetails.map((index)=>(
          <tr key={index.id}>
              <td >{index.customerName}</td>
              <td >{index.policyNumber}</td>
              <td >{index.renewalDate}</td>
              <td >{index.billAmount}</td>
              <td>Pay</td>
          </tr>
            ))):(<tr style={{position:"relative",left:"40%"}}>No data Available</tr>)}
        </tbody>
      </table>
    </div>
  )
}
