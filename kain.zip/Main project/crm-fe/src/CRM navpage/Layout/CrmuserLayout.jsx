import { Outlet } from "react-router-dom";
import { Sidebar } from "../Sidebar/Sidebar";
import { Navbar } from "../../Landindpage/Common/Navbar/Navbar";
import './CrmuserLayout.css'



export default function Layout() {
  return (
    <div className="Layout-sidebar">
      <Sidebar/>
      <div>
      <Outlet />
      </div>
    </div>
  )
}

