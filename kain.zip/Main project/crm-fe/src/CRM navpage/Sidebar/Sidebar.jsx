// import LOGO from "./inslogo.png";
import { Link, useNavigate } from "react-router-dom";
import "./Sidebar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faGaugeHigh,
  faPersonMilitaryPointing,
  faBarsStaggered,
  faRightFromBracket,
  faUser,
  faHandsHelping,
  faHandHoldingDollar,
  faClipboardList,
} from "@fortawesome/free-solid-svg-icons";
import { useEffect } from "react";
import axiosInstance from "../../Utils/axiosInstance";

export const Sidebar = () => {
  const navigate = useNavigate();

  // Check if the user is authenticated and navigate accordingly
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/");
    }
  }, [navigate]);

  // Handle logout click
  // const handleLogout = () => {
  //   localStorage.removeItem("token");
  //   localStorage.removeItem("hash_email");
  //   window.location.href = "/"; // Redirect to home page
  // };
  const handleLogout = async () => {
    try {
      // const response = await axiosInstance.post('/ins/logout');

      // if (response.status === 200) {
      //     // If the token is blacklisted or expired, log out the user
      //     console.log("blacklist,L 132");
      //     localStorage.removeItem("token");
      //     localStorage.removeItem("hash");
      //     window.location.href = '/';  // Redirect to login page
      // } else {
      //     const data = await response.json();
      //     console.log(data);
      // }
      // Open the external URL to end the session in the same window
      window.open("https://uat.zustpe.com/account/session/end", "_self");

      // Listen for the unloading of the page
      // window.onbeforeunload = function () {
      //   // Once the user leaves, clear the localStorage and redirect
      //   localStorage.removeItem("token");
      //   localStorage.removeItem("hash");
      //   window.location.href = "/"; // Redirect to the homepage
      // };
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <div className="sidebar">
        <div className="crm-user-title">
          {/* <h2 style={{ color: "white" }}>CRM</h2> */}
          {/* <img src={LOGO} alt="logo" className="CRMlogo"/> */}
        </div>
        <nav>
          <ul>
            <li>
              <Link to="/ins/user-dashboard">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faGaugeHigh}
                />{" "}
                Dashboard
              </Link>
            </li>
            <li>
              <Link to="/ins/user-customer">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faPersonMilitaryPointing}
                />{" "}
                Customer
              </Link>
            </li>
            <li>
              <Link to="/ins/user-pipeline">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faBarsStaggered}
                />{" "}
                Pipeline
              </Link>
            </li>
            <li>
              <Link to="/ins/integration">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faUser}
                />{" "}
                Integration
              </Link>
            </li>
            <li>
              <Link to="/ins/agency">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faHandsHelping}
                />{" "}
                Supported Agency
              </Link>
            </li>
            <li>
              <Link to="/ins/upcoming-payments">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faHandHoldingDollar}
                />{" "}
                Upcoming Payments
              </Link>
            </li>
            <li>
              <Link to="/ins/policies">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faClipboardList}
                />{" "}
                Policies
              </Link>
            </li>
          </ul>
        </nav>
        <div className="crm_logout">
          <Link to="/" onClick={handleLogout} className="crm-logout">
            <FontAwesomeIcon
              style={{ color: "red", fontSize: "20px" }}
              icon={faRightFromBracket}
            />{" "}
            Logout
          </Link>
        </div>
      </div>
    </div>
  );
};
