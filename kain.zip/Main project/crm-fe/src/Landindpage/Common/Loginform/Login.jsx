import Styles from "./Login.css";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../../Utils/axiosInstance.js";
import axios from "axios";

const Userlogin = () => {
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const code = new URLSearchParams(window.location.search).get("code");
  const state = new URLSearchParams(window.location.search).get("state");
  const iss = new URLSearchParams(window.location.search).get("iss");

  useEffect(() => {
    const IdpVerify = async () => {
      const params = new URLSearchParams();
      params.append("code", code);
      params.append("state", state);
      params.append("iss", iss);

      try {
        const response = await axios.post(
          "http://192.168.1.12:5100/api/ins/idpverify",
          params,
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            withCredentials: true,
          }
        );

        if (response.status === 200) {
          // Once verified, get the access token

          localStorage.setItem("hash", response.data.hash);
          localStorage.setItem("token", response.data.token);
        }
        const token = localStorage.getItem("token");
        const hash = localStorage.getItem("hash");
        if (token && hash) {
          // console.log(token, "................", hash, "............");
          navigate("/ins/user-dashboard");
        }
      } catch (error) {
        // console.log(error, "saffdsfdgf");
      }
    };
    IdpVerify();
  }, []);

  // const inputs = [
  //   {
  //     id: 1,
  //     name: "email",
  //     type: "email",
  //     placeholder: "Email",
  //     errormessage: "Invalid email",
  //     pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
  //     label: "Email",
  //     required: true,
  //   },
  //   {
  //     id: 2,
  //     name: "password",
  //     type: "password",
  //     placeholder: "Password",
  //     errormessage:
  //       "Password should be 8-20 characters and include at least 1 letter, 1 number, and 1 special character",
  //     label: "Password",
  //     required: true,
  //   },
  // ];

  // const handleChange = (e) => {
  //   const { name, value } = e.target;
  //   setValues({ ...values, [name]: value });
  // };

  // const validateForm = () => {
  //   let formErrors = {};
  //   const emailRegex = new RegExp(inputs[0].pattern);
  //   const passwordRegex = new RegExp(inputs[1].pattern);

  //   // Validate email
  //   if (!values.email) {
  //     formErrors.email = "Email is required.";
  //   } else if (!emailRegex.test(values.email)) {
  //     formErrors.email = "Invalid email format.";
  //   }

  //   // Validate password
  //   if (!values.password) {
  //     formErrors.password = "Password is required.";
  //   } else if (!passwordRegex.test(values.password)) {
  //     formErrors.password =
  //       "Password is incorrect. Please ensure it meets the criteria.";
  //   }

  //   setErrors(formErrors);
  //   return Object.keys(formErrors).length === 0;
  // };

  // const handleSubmit = async (e) => {
  //   e.preventDefault();

  //   // Validate form before submitting
  //   const isValid = validateForm();

  //   if (isValid) {
  //     // If the form is valid, send the login request
  //     axiosInstance
  //       .post(`/ins/login`, values)
  //       .then((res) => {
  //         // console.log(res.data);
  //         if (res.data.code === 200) {
  //           // Save accessToken to localStorage
  //           // localStorage.setItem("token", res.data.accessToken);

  //           // Optionally, store the user hash (or any other user identifier) in localStorage
  //           // localStorage.setItem("hash", res.data.data);

  //           // Set the Authorization header globally
  //           axiosInstance.defaults.headers[
  //             "Authorization"
  //           ] = `Bearer ${res.data.accessToken}`;

  //           // Clear form values and navigate to dashboard
  //           setValues({});
  //           navigate("/ins/user-dashboard");
  //         } else {
  //           // If login failed, show error message
  //           setErrors({
  //             ...errors,
  //             general: res.data.message,
  //           });
  //         }
  //       })
  //       .catch((err) => {
  //         e.preventDefault();
  //         // console.log(err, "Error in signing in user");
  //         setErrors({
  //           ...errors,
  //           general: "An error occurred. Please try again later.",
  //         });
  //       });
  //   }
  // };

  const IDP = async () => {
    // window.open("http://localhost:5000/api/ins/login","_self")
    window.open("http://192.168.1.12:5100/api/ins/login", "_self");
  };
  return (
    <div className="app">
      {/* <form className="form" onSubmit={handleSubmit} autoComplete="off">
        <h1 className="form-title">Login</h1>
        {inputs.map((input) => (
          <div className="formInput" key={input.id}>
            <label className="form-label">{input.label}</label>
            <input
              {...input}
              className="form-input"
              value={values[input.name] || ""}
              onChange={handleChange}
            />
     
            {errors[input.name] && (
              <span className="error">{errors[input.name]}</span>
            )}
          </div>
        ))}

      
        {errors.general && (
          <span
            className="error"
            style={{
              textAlign: "center",
              display: "block",
              margin: "10px",
              fontSize: "0.9em",
            }}
          >
            {errors.general}
          </span>
        )}
        <button type="submit" className="form-button">
          Login
        </button>
        <p className="form-text">
          Don't have an account? <Link to="/register">Create an account</Link>
        </p>
      </form> */}

      <div
        className={Styles.landing_page}
        style={{ backgroundColor: "#490960", padding: "15px" }}
      >
        <header className={Styles.navbar_container}>
          <nav className={Styles.navbar}>
            <span
              onClick={IDP}
              style={{ fontSize: "25px", color: "white", cursor: "pointer" }}
            >
              login
            </span>
          </nav>
        </header>
      </div>
    </div>
  );
};

export default Userlogin;
