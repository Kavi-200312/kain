import { Link } from "react-router-dom";
import "./Navbar.css";

const Navbar = () => {
  const IDP = async () => {
    window.open("http://192.168.1.12:5100/api/ins/login", "_self");
  };
  return (
    <div
      className="landing-page"
      style={{ backgroundColor: "#490960", padding: "15px" }}
    >
      <header className="navbar-container">
        <nav className="navbar">
          <span
            onClick={IDP}
            style={{ fontSize: "25px", color: "white", cursor: "pointer" }}
          >
            login
          </span>
        </nav>
      </header>
    </div>
  );
};

export default Navbar;
