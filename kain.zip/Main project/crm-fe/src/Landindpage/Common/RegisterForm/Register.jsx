// import "./Register.css";
// import { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axiosInstance from "../../../Utils/axiosInstance";

// const Useregister = () => {
//   const [values, setValues] = useState({});
//   const [focused, setFocused] = useState({});
//   const [errorMessage, setErrorMessage] = useState("");
//   const navigate = useNavigate();
//   //  console.log("i am in register");

//   const handleFocus = (name) => {
//     setFocused((prev) => ({ ...prev, [name]: true }));
//   };

//   const inputs = [
//     {
//       id: 1,
//       name: "username",
//       type: "text",
//       placeholder: "Username",
//       errormessage:
//         "Username should be 3-16 characters and shouldn't include any special characters",
//       pattern: "^[a-zA-Z0-9]{3,16}$",
//       label: "Name",
//       required: true,
//     },
//     {
//       id: 2,
//       name: "email",
//       type: "email",
//       errormessage: "It should be a valid email",
//       pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
//       placeholder: "Email",
//       label: "Email",
//       required: true,
//     },
//     {
//       id: 3,
//       name: "mobilenumber",
//       type: "text",
//       errormessage: "It should be a valid mobile number",
//       pattern: "^[6-9][0-9]{9}$",
//       placeholder: "Mobile Number",
//       label: "Mobile Number",
//       required: true,
//       maxLength: 10, // Added maxLength to input
//     },
//     {
//       id: 4,
//       name: "password",
//       type: "password",
//       errormessage:
//         "Password should be 8-20 characters and include at least 1 letter, 1 number, and 1 special character",
//       placeholder: "Password",
//       pattern: "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,20}$",
//       label: "Password",
//       required: true,
//     },
//     {
//       id: 5,
//       name: "confirmPassword",
//       type: "password",
//       errormessage: "Passwords don't match!",
//       placeholder: "Confirm Password",
//       label: "Confirm Password",
//       required: true,
//     },
//   ];

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setValues({ ...values, [name]: value });
//     if (name === "confirmPassword") {
//       setFocused({ ...focused, confirmPassword: true });
//     }
//     setErrorMessage(""); // Reset error message on change
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Client-side validation
//     for (const input of inputs) {
//       const { name, pattern, required } = input;
//       if (required && !values[name]) {
//         setErrorMessage(`${input.label} is required.`);
//         return;
//       }
//       if (pattern && !new RegExp(pattern).test(values[name])) {
//         setErrorMessage(input.errormessage);
//         return;
//       }
//     }

//     if (values.password !== values.confirmPassword) {
//       setErrorMessage("Passwords do not match.");
//       return;
//     }

//     // Submit to API
//     try {
//       const res = await axiosInstance.post(`/ins/register`, values);
//       if (res.data.code === 200) {
//         localStorage.setItem("hash", res.data.hash);
//         setValues({});
//         navigate("/login");
//       } else {
//         // alert(res.data.message);
//         setValues({});
//       }
//     } catch (err) {
//       // console.log(err, "error in registering user details");
//       setErrorMessage("An error occurred. Please try again later.");
//     }
//   };

//   return (
//     <div className="app">
//       <form className="form" onSubmit={handleSubmit} autoComplete="off">
//         <h1 className="form-title">Register</h1>
//         {inputs.map((input) => (
//           <div className="formInput" key={input.id}>
//             <label className="form-label">{input.label}</label>
//             <input
//               {...input}
//               className="form-input"
//               value={values[input.name] || ""}
//               onChange={handleChange}
//               onFocus={() => handleFocus(input.name)}
//               onBlur={() =>
//                 setFocused((prev) => ({ ...prev, [input.name]: false }))
//               }
//             />
//             {focused[input.name] && !values[input.name] && (
//               <span className="error">{input.errormessage}</span>
//             )}
//             {input.name !== "confirmPassword" &&
//               focused[input.name] &&
//               values[input.name] &&
//               !new RegExp(input.pattern).test(values[input.name]) && (
//                 <span className="error">{input.errormessage}</span>
//               )}
//             {input.name === "confirmPassword" &&
//               values[input.name] !== values.password && (
//                 <span className="error">{input.errormessage}</span>
//               )}
//           </div>
//         ))}
//         {errorMessage && <div className="error-message">{errorMessage}</div>}
//         <button type="submit" className="form-button">
//           Register
//         </button>
//         <p className="form-text">
//           Already have an account? <Link to="/login">Login here</Link>
//         </p>
//       </form>
//     </div>
//   );
// };

// export default Useregister;
