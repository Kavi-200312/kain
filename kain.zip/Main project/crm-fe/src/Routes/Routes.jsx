import { createBrowserRouter, RouterProvider } from "react-router-dom";
import NotFound from "../NotFount/Errorpage";
import Customer from "../CRM navpage/Pages/Customer/Customer";
import { Dashboard } from "../CRM navpage/Pages/Dashboard/Dashboard";
import Userlogin from "../Landindpage/Common/Loginform/Login";
import Navbar from "../Landindpage/Common/Navbar/Navbar";
import Integration from "../CRM navpage/Pages/Integration/Integration";
import Agency from "../CRM navpage/Pages/Agency/Agency";
import UpcomingPayments from "../CRM navpage/Pages/UpcomingPayments/UpcomingPayments";
import Policies from "../CRM navpage/Pages/Policies/Policies";
import Layout from "../CRM navpage/Layout/CrmuserLayout";
import Pipeline from "../CRM navpage/Pages/Pipeline/Pipeline";


function App() {
  const router = createBrowserRouter([
    // {
    //   path:"/ins",
    //   element:<Navbar/>,
    // },
    // { path: "register", element: <Useregister /> },
    { path: "/ins/login", element: <Userlogin /> },
    // { path: "/login", element: <Userlogin /> },
    {
      path: "/ins",
      element: <Layout />,
      errorElement:<NotFound/>,
      children: [
        { path: "user-dashboard", element: <Dashboard /> },
        { path: "user-customer", element: <Customer /> },
        { path: "user-pipeline", element: <Pipeline /> },
        { path: "integration", element: <Integration/> },
        { path: "agency", element: <Agency/> },
        { path: "upcoming-payments", element: <UpcomingPayments/> },
        { path: "policies", element: <Policies/> },
      ],
    },
  ]);

  return (
    <div>
      <RouterProvider router={router} />
    </div>
  );
}
export default App;
