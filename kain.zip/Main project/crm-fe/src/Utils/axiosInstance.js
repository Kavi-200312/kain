import axios from 'axios';

// Base URL for your backend
const CRM_URL = "http://192.168.1.12:5100/api";  

// Function to get the token from localStorage
const getToken = () => {
  return localStorage.getItem('token');  
};

// Function to get the hash from localStorage
const getHash = () => {
  return localStorage.getItem('hash');
};

// Create axios instance
const axiosInstance = axios.create({
  baseURL: CRM_URL,
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token = getToken();  
    const hash = getHash();    

    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;  
    }

    if (hash) {
      config.headers['mobile-hash'] = hash; 
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle response (e.g., token expiration)
axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      console.error('Unauthorized: Redirecting to login...');
      
      // Remove token and hash from localStorage
      localStorage.removeItem('token');
      localStorage.removeItem('hash');
      
      // Redirect to login page
      window.location.href = '/'; 
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;



