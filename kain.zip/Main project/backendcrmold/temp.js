
          // // Save TokenSet in the database
          // const newTokenSet = new TokenSet({
          //   access_token: tokenSet.access_token,
          //   expires_at: tokenSet.expires_at,
          //   id_token: tokenSet.id_token,
          //   refresh_token: tokenSet.refresh_token,
          //   scope: tokenSet.scope,
          //   token_type: tokenSet.token_type,
          // });

          // await newTokenSet.save();
          // console.log('TokenSet saved to database');

          // // Save UserInfo in the database
          // const newUserInfo = new UserInfo({
          //   phone_number: userinfo.phone_number,
          //   hash: userinfo.hash,
          //   name: userinfo.name,
          //   scopes: userinfo.scopes,
          //   sub: userinfo.sub,
          // });

          // await newUserInfo.save();
          // console.log('UserInfo saved to database');













          // require("dotenv").config();
// const express = require("express");
// const app = express();
// const cors = require("cors");
// const router = require("./Router/Router");
// const session = require("express-session");
// const { Issuer, Strategy, custom } = require("openid-client");
// const passport = require("passport");
// const fileupload = require("express-fileupload");
// require("dotenv").config();
// const port = process.env.PORT;
// const helmet = require("helmet");
// app.use(helmet());
// app.use(
//   cors({
//     origin: process.env.CORS_URL.split(","),
//     credentials: true,
//     allowedHeaders: ["Content-Type", "Authorization"],
//   })
// );
// app.use(fileupload());
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static("Public"));
// app.set("view engine", "ejs");
// app.use(
//   session({
//     secret: "secret",
//     resave: false,
//     saveUninitialized: true,
//   })
// );

// app.use(passport.initialize());
// app.use(passport.session());
// const TokenModel = require("./Models/Token");
// const { LoadSocialMediaCollection } = require("./utils/SocilaMediaAppsLoad");

// passport.serializeUser((user, done) => {
//   done(null, user);
// });

// passport.deserializeUser(async (user, done) => {
//   done(null, user);
// });

// Issuer.discover(`${process.env.IDP_SERVER}`).then(function (oidcIssuer) {
//   var client = new oidcIssuer.Client({
//     client_id: `${process.env.CLIENTID}`,
//     client_secret: `${process.env.CLIENTSECRET}`,
//     redirect_uris: process.env.REDIRECT_URI.split(","),
//     response_types: ["code"],
//   });

//   passport.use(
//     "oidc",
//     new Strategy(
//       { client, passReqToCallback: true },
//       async (req, tokenSet, userinfo, done) => {
//         // client.refresh(tokenSet.refresh_token);
//         if (tokenSet && userinfo) {
//           const data = {
//             Auth_token: tokenSet.access_token,
//             hash: userinfo.hash,
//           };

//           const fii = await TokenModel.create({
//             hash: userinfo.hash,
//             accessToken: tokenSet.access_token,
//             refreshToken: tokenSet.refresh_token,
//             expireTime: tokenSet.expires_at,
//             jwt: tokenSet.id_token,
//           });

//           return done(null, data);
//         } else {
//           return done("Auth error", false);
//         }
//       }
//     )
//   );
// });

// app.get(
//   "/api/gateway/",
//   passport.authenticate("oidc", {
//     scope: "openid refresh_token",
//   })
// );

// app.post("/api/gateway/login", passport.authenticate("oidc"), (req, res) => {
//   return res.status(200).json({ token: req.user.Auth_token, code: 200 });
// });

// app.use("/api/gateway", router);

// const server = app.listen(port, () => console.log(`server running at ${port}`));
// LoadSocialMediaCollection();
// server.on("request", (req, res) => {
//   console.log(`${req.method}----${req.url}`);
// });

// ============================================

// combined WEb and native flow

require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const router = require("./Router/Router");
const session = require("express-session");
const { Issuer, Strategy, custom, generators } = require("openid-client");
const passport = require("passport");
const fileupload = require("express-fileupload");
require("dotenv").config();
const port = process.env.PORT;
const helmet = require("helmet");
app.use(helmet());
app.use(
  cors({
    origin: process.env.CORS_URL.split(","),
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(fileupload());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("Public"));
app.set("view engine", "ejs");
app.use(
  session({
    httpOnly: true,
    secret: "secret",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true },
  })
);

app.use(
  session({
    secret: "secret",
    resave: false,
    saveUninitialized: true,
  })
);

app.use(passport.initialize());
app.use(passport.session());
const TokenModel = require("./Models/Token");
const { LoadSocialMediaCollection } = require("./utils/SocilaMediaAppsLoad");
const PKCModel = require("./Models/pkc.model");
const { default: axios } = require("axios");
const { isMobileUserAgent } = require("./utils/deviceUtils");

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser(async (user, done) => {
  done(null, user);
});

const IDP_SERVER = process.env.IDP_SERVER;
const CLIENTID = process.env.CLIENTID;
const CLIENTSECRET = process.env.CLIENTSECRET;
const REDIRECT_URI = process.env.REDIRECT_URI;

let oidcIssuer;

Issuer.discover(IDP_SERVER)
  .then((issuer) => {
    oidcIssuer = issuer;
    const client = new oidcIssuer.Client({
      client_id: CLIENTID,
      client_secret: CLIENTSECRET,
      redirect_uris: REDIRECT_URI.split(","),
      response_types: ["code"],
    });

    // Passport strategy setup
    passport.use(
      "oidc",
      new Strategy(
        { client, passReqToCallback: true },
        async (req, tokenSet, userinfo, done) => {
          try {
            if (tokenSet && userinfo) {
              const data = {
                Auth_token: tokenSet.access_token,
                hash: userinfo.hash,
              };

              await TokenModel.create({
                hash: userinfo.hash,
                accessToken: tokenSet.access_token,
                refreshToken: tokenSet.refresh_token,
                expireTime: tokenSet.expires_at,
                jwt: tokenSet.id_token,
              });

              return done(null, data);
            } else {
              return done("Auth error", false);
            }
          } catch (error) {
            console.error("Error during OIDC authentication:", error);
            return done(error);
          }
        }
      )
    );

    app.get("/api/gateway/", async (req, res) => {
      // console.log(req);
      
      try {
        const userAgent = req.headers["user-agent"] || "";
        const isMobile = isMobileUserAgent(userAgent);
console.log(isMobile,"IS MOBILE");

        if (!isMobile) {
          // Web Flow
          console.log(isMobile,"IS MOBILE");
          passport.authenticate("oidc", { scope: "openid refresh_token" });
        } else {
          // Mobile Flow to Generate PKCE values
          console.log("Request is coming from a mobile device.");

          const state = generators.state();
          const codeVerifier = generators.codeVerifier();
          const codeChallenge = generators.codeChallenge(codeVerifier);

          req.session["oidc:192.168.1.10"] = {
            state,
            response_type: "code",
            code_verifier: codeVerifier,
          };

          const pkcData = new PKCModel({
            _id: state,
            state,
            code_challenge: codeChallenge,
            code_verifier: codeVerifier,
          });
          await pkcData.save();

          const AuthorizationUrl = client.authorizationUrl({
            scope: "openid refresh_token",
            code_challenge: codeChallenge,
            code_challenge_method: "S256",
            state,
          });

          console.log(AuthorizationUrl, "++++++++AuthorizationUrl");
          res.redirect(AuthorizationUrl);
        }
      } catch (error) {
        console.error("Error in /api/gateway/ route:", error);
        res.status(500).send("Internal server error");
      }
    });
  })
  .catch((err) => {
    console.error("Issuer discovery failed:", err);
    process.exit(1);
  });

app.post("/api/gateway/login", passport.authenticate("oidc"), (req, res) => {
  return res.status(200).json({ token: req.user.Auth_token, code: 200 });
});

// app.post("/api/gateway/login", async (req, res) => {
//   const userAgent = req.headers["user-agent"] || "";
//   console.log(userAgent, "userAgent");
//   const isMobile = isMobileUserAgent(userAgent);
//   console.log(isMobile, "isMobile");

//   //WEB FLOW
//   if (!isMobile) {
//     console.log(" //WEB FLOW");
//     return (
//       passport.authenticate("oidc", { session: false }),
//       (req, res) => {
//         console.log(req, "____req");

//         return res.status(200).json({ token: req.user.Auth_token, code: 200 });
//       }
//     );
//   }

//   const { code, state } = req.body;
//   if (!code || !state) {
//     return res.status(400).json({
//       message: "Missing required parameters: code or state",
//     });
//   }

//   try {
//     const user = await PKCModel.findOne({ _id: state });
//     if (!user) {
//       return res.status(400).json({ message: "Invalid state parameter" });
//     }

//     const { code_verifier } = user;
//     if (!code_verifier) {
//       return res.status(400).json({
//         message: "code_verifier not found for this state",
//       });
//     }

//     const { CLIENTID, CLIENTSECRET, IDP_SERVER, REDIRECT_URI } = process.env;
//     if (!CLIENTID || !CLIENTSECRET || !IDP_SERVER || !REDIRECT_URI) {
//       return res.status(500).json({
//         message:
//           "Client credentials (CLIENT_ID, CLIENT_SECRET, IDP_SERVER, REDIRECT_URI) not set in environment",
//       });
//     }

//     const credentials = `${CLIENTID}:${CLIENTSECRET}`;
//     const base64Credentials = Buffer.from(credentials).toString("base64");

//     const response = await axios.post(
//       `${IDP_SERVER}/account/token`,
//       new URLSearchParams({
//         grant_type: "authorization_code",
//         code,
//         redirect_uri: REDIRECT_URI,
//         code_verifier,
//       }).toString(),
//       {
//         headers: {
//           "Content-Type": "application/x-www-form-urlencoded",
//           Authorization: `Basic ${base64Credentials}`,
//         },
//       }
//     );

//     if (response.status === 200) {
//       console.log("Token response data:", response.data);
//       const { access_token, refresh_token, expires_in, id_token } =
//         response.data;

//       const expireTime = new Date().getTime() + expires_in * 1000;

//       await TokenModel.create({
//         accessToken: access_token,
//         refreshToken: refresh_token,
//         expireTime: expireTime,
//         jwt: id_token,
//       });

//       return res.status(200).json({
//         token: access_token,
//         code: 200,
//         data: response.data,
//       });
//     }

//     return res.status(500).json({ message: "Error obtaining token from IDP" });
//   } catch (error) {
//     console.error("Error during login process:", error);
//     if (error.response) {
//       console.error("Error response from IDP:", error.response.data);
//     } else if (error.request) {
//       console.error("No response received from IDP:", error.request);
//     } else {
//       console.error("Error in setting up the request:", error.message);
//     }

//     return res.status(500).json({ message: "Server error during login" });
//   }
// });

app.use("/api/gateway", router);

const server = app.listen(port, () => console.log(`server running at ${port}`));

LoadSocialMediaCollection();
server.on("request", (req, res) => {
  console.log(`${req.method}----${req.url}`);
});