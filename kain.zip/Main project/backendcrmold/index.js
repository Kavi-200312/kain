const express = require("express");
require("dotenv").config();
const cors = require("cors");
const connectDB = require("./Database/Db");
const router = require("./ROUTE/customerRoutes");

const session = require("express-session");
const helmet = require("helmet");
const passport = require("passport");
const cookieParser = require("cookie-parser");
const { Issuer, Strategy } = require("openid-client");
const path = require("path");
const { default: axios } = require("axios");
const { UserIdpInfo, UserInfo } = require("./Module/User");
const MongoStore = require("connect-mongo");
const TokenModel = require("./Module/TokenModel");
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Use cookie-parser middleware to parse cookies
app.use(cookieParser());

// Connect to MongoDB
connectDB();

app.use("/api/ins", router); // api routes

// app.use("/api/crm",)
app.use(
  cors({
    origin: "http://192.168.1.12:3000",
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(express.json({ limit: "15mb" }));
app.use(session({ secret: "secret", resave: false, saveUninitialized: true,
  store: MongoStore.create({ mongoUrl: 'mongodb://localhost/session_db' }),
  cookie: { maxAge: 1000 * 60 * 60 } // 1 hour expiration
}));
app.use(helmet());
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser(function (user, done) {
  // console.log("-----------------------------");
  // console.log("serialize user");
  // console.log(user);
  // console.log("-----------------------------");
  done(null, user);
});
passport.deserializeUser(function (user, done) {
  // console.log("-----------------------------");
  // console.log("deserialize user");
  // console.log(user);
  // console.log("-----------------------------");
  done(null, user);
});



Issuer.discover('https://uat.zustpe.com').then(function (oidcIssuer) {
    const client = new oidcIssuer.Client({
    client_id: process.env.CLIENT_ID,
    client_secret: process.env.CLIENT_SECRET,
    redirect_uris: ['http://192.168.1.12:3000/ins/login'],
    response_types: ['code'],
  });
  passport.use(
    "oidc",
    new Strategy(
      { client, passReqToCallback: true },
      async (req, tokenSet, userinfo, done) => {
        let data;
        // client.refresh(tokenSet.refresh_token);
        if (tokenSet && userinfo) {
          
          console.log('TokenSet:', tokenSet);
        console.log('UserInfo:', userinfo);
           data = {
            Auth_token: tokenSet.access_token,
            hash: userinfo.hash,
          };
          const userDetails =await UserInfo.create({
            hash:userinfo.hash,
            name:userinfo.name,
            phone_number:userinfo.phone_number,
            scopes:userinfo.scopes,
            sub:userinfo.sub,
          })
          const fii = await TokenModel.create({
            hash: userinfo.hash,
            accessToken: tokenSet.access_token,
            refreshToken: tokenSet.refresh_token,
            expireTime: tokenSet.expires_at,
            jwt: tokenSet.id_token,
          });

          return done(null, data);
        } else {
          return done("Auth error", false);
        }
      }
    )
  );
});



app.get(
  "/api/ins/login",
  function (req, res, next) {
    // console.log("-----------------------------");
    // console.log("/Start login handler");
    next();
    0;
  },
  passport.authenticate("oidc", { scope: "openid refresh_token" })
);


// app.get("/api/ins/login/callback", (req, res, next) => {
//   passport.authenticate("oidc", {
//     successRedirect: "/user",
//     failureRedirect: "/",
//   })(req, res, next);
// });



app.post("/api/ins/idpverify", passport.authenticate("oidc"),async(req,res,next)=>{
  try {
    // return res.status(200).json({message:"Success"})
    console.log(req.user.Auth_token);
    return res.status(200).json({ token: req.user.Auth_token,hash:req.user.hash, code: 200 });
  } catch (error) {
    return res.status(500).json({message:"Something wrong"})
  }
});



// app.get("/", (req, res) => {
//   res.send(" <a href='/login'>Log In with OAuth 2.0 Provider </a>");
// });


app.get("/api/ins/user", (req, res) => {
  res.header("Content-Type", "application/json");
  res.end(
    JSON.stringify(
      { tokenset: req.session.tokenSet, userinfo: req.session.userinfo },
      null,
      2
    )
  );
});



const PORT = process.env.PORT || 4000;
const server = app.listen(PORT, () => {
  console.log(`Server is connected on http://localhost:${PORT}`);
});
server.on("request", (req, res) => {
  console.log(req.method, ">>>>>>>>>>>>", req.originalUrl);
});
