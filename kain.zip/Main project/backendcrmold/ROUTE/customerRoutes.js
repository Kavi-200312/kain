const express = require("express");
const { addCustomer, getCustomers, getTotalCustomers } = require("../Controllers/customerController");
const { Savesms, viewMessagesByUser } = require("../Controllers/smsController");
const { addPipelineData, getPipelineData, getPipelineStatusCounts, updatePipelineData, upload, getPolicyDetails } = require("../Controllers/pipelineController");
const { InitiateCall } = require("../Controllers/callapi");
const { registerUser, userLogin } = require("../Controllers/userloginreg");
const { verifyJWT } = require("../middleware/auth");
const { userLogout } = require("../Controllers/authController");
const customerDetailsRenewAgency = require("../Controllers/supportedAgency");
const { refreshAccessToken } = require("../middleware/refreshToken");
const UpcomingPayments = require("../Controllers/upcomingPayments");
const PaymentProcess = require("../Controllers/integration");
const { loginIdp, loginCallback, userIdp } = require("../Controllers/IDPapi");
const passport = require("passport");
const router = express.Router();

//Idp 
// router.get("/login", loginIdp,passport.authenticate("oidc", {
//     scope: "openid refresh_token",
//   }));
// router.get("/login/callback", loginCallback);
// router.get("/user", userIdp);





//register and login api
router.post("/register", registerUser);
router.post("/login", userLogin)
router.post("/logout", userLogout)
router.post("/token", refreshAccessToken)

// router.use(verifyJWT);

// Route to add a customer
// Route to get all customers
router.post("/addcustomer",verifyJWT, addCustomer);
router.get("/getCustomers",verifyJWT, getCustomers);
// router.get("/totalcustomer",getTotalCustomers)
router.get('/totalcustomer', verifyJWT, getTotalCustomers);
router.post("/savesms",verifyJWT, Savesms)


// router.get("/sms/:adminNumber",verifyJWT, viewMessagesByUser);
// Route to get all pipeline data //pipeline 
router.post("/addpipeline",verifyJWT, addPipelineData);
router.get("/getpipeline",verifyJWT, getPipelineData);
router.get("/status-counts",verifyJWT, getPipelineStatusCounts);
router.get("/getPolicyDetails",verifyJWT, getPolicyDetails);
router.put("/updatepipeline",verifyJWT,upload, updatePipelineData);

//supported Agency
router.post("/customerDetailsRenewAgency",verifyJWT, customerDetailsRenewAgency);
router.get("/upcomingpayments",verifyJWT, UpcomingPayments);

///CousterCall Api
router.post('/trai/b2b/voice',verifyJWT, InitiateCall)


//payment

router.post('/paymentProcess',verifyJWT, PaymentProcess)

module.exports = router;
