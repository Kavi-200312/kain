const mongoose = require('mongoose');

const pipelineSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true,
    trim: true,
    match: [/^[A-Za-z\s]+$/, "Customer name should contain only letters and spaces"],
    maxlength: [25, "CustomerName should not exceed above 25 characters"]
  },
  contactNumber: { 
    type: String, 
    required: true, 
    match: [/^[6-7-8-9]\d{9}$/, "Please enter a valid 10-digit Indian contact number starting with 6, 7, 8, or 9"] ,
},
  referredBy: {
    type: String,
    required: true,
    trim: true,
    match: [/^[A-Za-z\s]+$/, "Referred by should contain only letters and spaces"],
  },
  description: {
    type: String,
    required: true,
    maxlength: [160, "Description should not exceed 160 characters"],
  },
  status: {
    type: String,
    enum: ["Referral", "Lead", "In Discussion", "Customer", "Closed"],
    default: "Referral",
    required: true,
  },
  policy: {
    type: String,
    required: false,
    trim: true,
    maxlength: [35, "Policy name should not exceed 35 characters"]
  },
  billerName: {
    type: String,
    required: false,
    trim: true,
    match: [/^[A-Za-z\s]+$/, "Biller name should contain only letters and spaces"],
    maxlength: [35, "Biller name should not exceed 35 characters"]
  },
  policyNumber: {
    type: Number,
    required: false
  },
  startingDate: {
    type: Date,
    default: Date.now,
    required: false
  },
  endingDate: {
    type: Date,
    required: false
  },
  DOB: {
    type: Date,
    required: false
  },
  amountPaid: {
    type: Number,
    required: false
  },
  document: {
    type: Buffer,  // Change this to Buffer to store file binary data
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  hash: {
    type: String
  }
});

const Pipeline = mongoose.model("Pipeline", pipelineSchema);
module.exports = Pipeline;
