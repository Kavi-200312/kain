const mongoose = require('mongoose');

// Define the schema for customer details
const customerSchema = new mongoose.Schema({
  selectedAgency:{
    type: String,
    required: [true, 'Customer Name is required'],
    minlength: [3, 'Customer Name must be at least 3 characters long'],
    maxlength: [35, 'Customer Name must be less than 35 characters long'],
    match: [/^[A-Za-z\s]+$/, 'Customer Name must be alphabetic'],
    enum:["HDFC","ICIC","SIB","LIC"]
  },
  customerName: {
    type: String,
    required: [true, 'Customer Name is required'],
    minlength: [3, 'Customer Name must be at least 3 characters long'],
    maxlength: [35, 'Customer Name must be less than 35 characters long'],
    match: [/^[A-Za-z\s]+$/, 'Customer Name must be alphabetic'],
  },
  policyNumber: {
    type: String,
    required: [true, 'Policy Number is required'],
    match: [/^\d{8,10}$/, 'Policy Number must be between 8 and 10 digits'],
  },
  dob: {
    type: Date,
    required: [true, 'Date of Birth is required'],
    validate: {
      validator: function (value) {
        // Ensure DOB is after 1960-01-01
        return value >= new Date('1960-01-01');
      },
      message: 'Date of Birth must be after January 1, 1960',
    },
  },

});

// Create the model from the schema
const AgencyModel = mongoose.model('supportedAgency', customerSchema);

module.exports = AgencyModel;
