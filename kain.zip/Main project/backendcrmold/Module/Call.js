const mongoose = require("mongoose");

const callSchema = new mongoose.Schema({
  AdminNumber: {
    type: String,
    required: true,
    match: [
      /^[6-7-8-9]\d{9}$/,
      "Please enter a valid 10-digit Indian Admin number starting with 6, 7, 8, or 9",
    ],
  },
  CustomerNumber: {
    type: String,
    required: true,
    match: [
      /^[6-7-8-9]\d{9}$/,
      "Please enter a valid 10-digit Indian Customer number starting with 6, 7, 8, or 9",
    ],
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    default: "initiated", // Other statuses could include 'completed', 'failed', etc.
  },
});

const Call = mongoose.model("Call", callSchema);

module.exports = Call;
