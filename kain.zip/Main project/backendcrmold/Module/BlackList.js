const mongoose = require('mongoose');
const connectDB = require('../Database/Db');

const blacklistSchema = new mongoose.Schema({
    token: {
        type: String,
        required: true,
        unique: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    expiresAt: {
        type: Date,
    },
});

// Create a model for the blacklist
const Blacklist = mongoose.model('Blacklist', blacklistSchema);

module.exports = Blacklist;
