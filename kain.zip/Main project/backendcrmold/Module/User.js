// const mongoose = require("mongoose")
// const bcrypt = require("bcrypt")
// const jwt = require("jsonwebtoken")
// const crypto = require("crypto");
// const { type } = require("os");

// const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

// const userSchema = new mongoose.Schema({
//     fullname: { type: String },
//     email: {
//         type: String,
//         required: true,
//         unique: true,
//         lowercase: true,
//         trim: true
//     },
//     password: {
//         type: String,
//         required: true,
//     },
//     mobile_number: {
//         type: String,
//         unique: true,
//     },
//     account_created_date: { type: Date, default: Date.now },
//     email_hash: { type: String },
//     refreshToken: { type: String },
//     // customer :[{type:Object}],
//     // pipelineSchema:[{type:Object}]

// }, { timestamps: true });

// userSchema.pre("save", async function (next) {
//     if (this.isModified("password")) {
//         // console.log("Original password:", this.password);
//         if (!passwordRegex.test(this.password)) {
//             return next(new Error('Password must be at least 8 characters long, include at least one letter, one digit, and one special character.'));
//         }
//         const saltRounds = 12;
//         try {
//             this.password = await bcrypt.hash(this.password, saltRounds);
//         } catch (error) {
//             return next(error);
//         }
//     }
//     if (this.isModified("email")) {
//         try {
//             const hash = crypto.createHash('sha256');
//             hash.update(this.email);
//             this.email_hash = hash.digest('hex');
//             // console.log("Hashed email:", this.email_hash);
//         } catch (error) {
//             console.log("Error in saving email hash:", error);
//             return next(error);
//         }
//     }
//     next();
// })

// userSchema.methods.isPasswordCorrect = async function (password) {
//     return await bcrypt.compare(password, this.password);
// }

// const User = mongoose.model("User", userSchema);

// module.exports = { User }



const mongoose = require('mongoose');

// TokenSet Schema
const tokenSetSchema = new mongoose.Schema({
  access_token: { type: String, required: true },
  expires_at: { type: Number, required: true },
  id_token: { type: String, required: true },
  refresh_token: { type: String, required: true },
  scope: { type: String, required: true },
  token_type: { type: String, required: true },
}, { timestamps: true });

// UserInfo Schema
const userInfoSchema = new mongoose.Schema({
  phone_number: { type: String, required: true },
  hash: { type: String, required: true },
  name: { type: String, required: true },
  scopes: { type: [String], required: true },
  sub: { type: String, required: true },
}, { timestamps: true });

// Create Mongoose Models
const TokenSet = mongoose.model('TokenSet', tokenSetSchema);
const UserInfo = mongoose.model('UserInfo', userInfoSchema);


const TokenSetSchema = new mongoose.Schema({
    access_token: String,
    expires_at: Number,
    id_token: String,
    refresh_token: String,
    scope: String,
    token_type: String,
  });
  
  const UserInfoSchema = new mongoose.Schema({
    phone_number: String,
    hash: String,
    name: String,
    scopes: [String],
    sub: String,
  });
  
  const UserSchema = new mongoose.Schema({
    tokenSet: TokenSetSchema,
    userinfo: UserInfoSchema,
  });
  
  const UserIdpInfo = mongoose.model("UserIdpInfo", UserSchema);



module.exports = { TokenSet, UserInfo ,UserIdpInfo};
