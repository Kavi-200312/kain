const jwt = require("jsonwebtoken");
const { User } = require("../Module/User");
const Blacklist = require("../Module/BlackList");
const TokenModel = require("../Module/TokenModel");
const { ACCESS_TOKEN_SECRET_KEY } = process.env;

const verifyJWT = async (req, res, next) => {
  try {
    // Get token from Authorization header
    // const authHeader = req.headers["authorization"];
    // const token = authHeader && authHeader;
    
    // if (!token) {
    //   return res.status(401).json({ message: "Token not found" });
    // }

    // // Verify the token (decodes and checks validity)
    // let decodedToken;
    // try {
    //   decodedToken = jwt.verify(token);
    // } catch (err) {
    //   return res.status(403).json({ message: "Invalid or expired token" });
    // }

    // Check if the token is blacklisted
    // const blacklistedToken = await Blacklist.findOne({ token });
    // if (blacklistedToken) {
    //   return res.status(401).json({
    //     code: 401,
    //     message: "Token has been blacklisted. Please log in again.",
    //   });
    // }

    // Get the email_hash from the custom header ('x-email-hash')
    const hash = req.headers["mobile-hash"];
    
    if (!hash) {
      return res.status(400).json({ message: "hash not provided" });
    }

    // // Find the user based on email hash
    const user = await TokenModel.findOne({ hash });

    // if (!user) {
    //   return res.status(401).json({ message: "User not found" });
    // }

    // Attach user information to the request object
    req.user = user;

    // Proceed to the next middleware or route handler
    next();

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = { verifyJWT };





















// const verifyJWT = async (req, res, next) => {
//   try {
//     // Get token from Authorization header
//     const authHeader = req.headers["authorization"];
//     const token = authHeader && authHeader;
    
//     if (!token) {
//       return res.status(401).json({ message: "Token not found" });
//     }

//     // Verify the token (decodes and checks validity)
//     let decodedToken;
//     try {
//       decodedToken = jwt.verify(token);
//     } catch (err) {
//       return res.status(403).json({ message: "Invalid or expired token" });
//     }

//     // Check if the token is blacklisted
//     // const blacklistedToken = await Blacklist.findOne({ token });
//     // if (blacklistedToken) {
//     //   return res.status(401).json({
//     //     code: 401,
//     //     message: "Token has been blacklisted. Please log in again.",
//     //   });
//     // }

//     // Get the email_hash from the custom header ('x-email-hash')
//     // const emailHash = req.headers["x-email-hash"];
    
//     // if (!emailHash) {
//     //   return res.status(400).json({ message: "Email hash not provided" });
//     // }

//     // // Find the user based on email hash
//     const user = await TokenModel.findOne({ hash: hash });

//     // if (!user) {
//     //   return res.status(401).json({ message: "User not found" });
//     // }

//     // Attach user information to the request object
//     req.user = user;

//     // Proceed to the next middleware or route handler
//     next();

//   } catch (error) {
//     return res.status(500).json({ message: error.message });
//   }
// };
