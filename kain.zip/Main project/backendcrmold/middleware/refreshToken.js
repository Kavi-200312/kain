


const jwt = require("jsonwebtoken");
const { User } = require("../Module/User");
const RefreshToken = require("../Module/RefreshToken");

const refreshAccessToken = async (req, res) => {
  try {
    const { email_hash } = req.body;  // Get refresh token from request body

    if (!email_hash) {
      return res.status(401).json({ message: "Refresh token is required" });
    }

    // Find the refresh token in the database
    const storedToken = await RefreshToken.findOne({ email_hash });
    if (!storedToken) {
      return res.status(403).json({ message: "Invalid or expired refresh token" });
    }
    // console.log(storedToken)

    // Check if the refresh token has expired
    // if (storedToken.expiresAt < Date.now()) {
    //   return res.status(403).json({ message: "Refresh token has expired" });
    // }

    // Decode the refresh token to get the user data
    const decoded = jwt.verify(storedToken.refreshToken, process.env.REFRESH_TOKEN_SECRET_KEY);

    // Find the user based on the decoded data
    // const user = await User.findById(decoded.userId);
    // if (!user) {
    //   return res.status(404).json({ message: "User not found" });
    // }

    // Generate a new access token
    const newAccessToken = jwt.sign(
      { email_hash: storedToken.email_hash, role: storedToken.role },
      process.env.ACCESS_TOKEN_SECRET_KEY,
      { expiresIn: "15m" }  // New access token expires in 15 minutes
    );

    return res.json({ accessToken: newAccessToken });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = { refreshAccessToken };
