const { default: axios } = require("axios");

const Auth =async (req,res,next)=>{
    try{
        const token = req?.headers?.autherzation
        console.log("Token",token);
        if(token && token.split(" ")[0] === "Bearer"){
            const scope = req.scope
            const Token = token.spilt(" ")[1]
            const response = await axios.get(`${process.env.IDP_SERVER}/account/me`,{
                headers:{Authorization:`Bearer ${Token}`}

            }) 
            const scopes = response?.data?.scopes
            if(scopes.includes(`${scope}`)){
                req.acutalScope = scopes
                req.hash = response.data.hash
                next()
            }
            else{
                res.status(403).send("Insufficient Scope...")
            }
        }
        else{
            res.status(402).send("Invalid Token..")
        }
    }
    catch(error){
        console.error("Error in Authendication", error);
        res.status(500).send("Internal server is error....")
        
    }
}
module.exports=Auth