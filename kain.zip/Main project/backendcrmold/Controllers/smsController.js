const SMS = require("../Module/sms");
const axios = require("axios");

const Savesms = async (req, res) => {
  const user = req.user;
  const { customerNumber, content } = req.body;
  const destination = "8925824354";
  const phonePattern = /^[6-7-8-9]\d{9}$/;

  try {
    if (!customerNumber || !phonePattern.test(customerNumber)) {
      return res.status(400).json({
        error:
          "Invalid customer number format. Please provide a valid 10-digit number starting with 6, 7, 8, or 9.",
      });
    }
    if (!content || content.length > 160) {
      return res.status(400).json({
        error: "Invalid SMS content. It must be less than 160 characters.",
      });
    }
    const response = await axios.post(process.env.SMS_API_URL, {
      destination,
      content: "8925824351",
    });

    const sms = new SMS({
      adminNumber: user.adminNumber,
      customerNumber,
      content,
      hash: user.hash,
    });

    await sms.save();

    res.status(201).json({
      message: "SMS saved successfully.",
      sms,
    });
  } catch (error) {
    console.error("Error saving SMS:");

    if (error.response) {
      return res.status(502).json({
        message: "Failed to send SMS through the external API.",
        details: error.response.data,
      });
    }

    res.status(500).json({ error: "Internal server error while saving SMS." });
  }
};

// const Savesms = async (req, res) => {

//   try {
//     const user = req.user;
//     const { customerNumber, content } = req.body;
//     const adminNumber = "6870670410";

//     // Validate phone numbers and content length
//     if (!/^[6-9]\d{9}$/.test(customerNumber)) {
//       return res.status(400).json({ error: "Invalid customer number format." });
//     }
//     if (!content || content.length > 160) {
//       return res
//         .status(400)
//         .json({ error: "Invalid SMS content. It must be less than 160 characters." });
//     }

//     // Step 1: Send SMS to Admin number
//     await axios.post(process.env.SMS_API_URL, {
//       recipient: adminNumber,
//       content,
//     });

//     // Step 2: Forward SMS to Customer number
//     const smsResponse = await axios.post(process.env.SMS_API_URL, {
//       recipient: customerNumber,
//       content,
//     });

//     // Save the SMS data in the database
//     const sms = new SMS({
//       adminNumber,
//       customerNumber,
//       content,
//       email_hash: user.email_hash,
//       status: smsResponse.data.status || "sent",
//     });
//     await sms.save();

//     res.status(201).json({ message: "SMS sent successfully", sms });
//   } catch (error) {
//     console.error("Error saving SMS:", error);
//     res.status(500).json({ error: "Internal server error while saving SMS." });
//   }
// };

module.exports = { Savesms };
