const Customer = require("../Module/Customer");
const TokenModel = require("../Module/TokenModel");
const { User } = require("../Module/User");

// Controller add new customer
const addCustomer = async (req, res) => {
  const { name, contactNumber, email, whatsappNumber } = req.body;
  const user = req.user;
  console.log(user.hash);

  try {
    if (!name || !contactNumber || !email) {
      return res
        .status(400)
        .json({
          msg: "Name, Contact Number, and Email are required.",
          code: 400,
        });
    }

    if (!/^[6-9]\d{9}$/.test(contactNumber)) {
      return res
        .status(400)
        .json({
          msg: "Please provide a valid 10-digit Indian contact number starting with 6-9.",
          code: 400,
        });
    }

    if (whatsappNumber && !/^[6-9]\d{9}$/.test(whatsappNumber)) {
      return res
        .status(400)
        .json({
          msg: "Please provide a valid 10-digit Indian WhatsApp number starting with 6-9.",
          code: 400,
        });
    }

    const existingCustomer = await Customer.findOne({ email });
    if (existingCustomer) {
      return res
        .status(400)
        .json({ msg: "Customer with this email already exists.", code: 400 });
    }

    const newCustomer = new Customer({
      name,
      contactNumber,
      email,
      whatsappNumber,
      hash: user.hash,
    });
    const savedCustomer = await newCustomer.save();

    return res
      .status(201)
      .json({ msg: "New customer data added to DB." });
  } catch (error) {
    if (error.name === "ValidationError") {
      return res
        .status(400)
        .json({ msg: "Validation error", details: error.message });
    }

    return res.status(500).json({ msg: "Error saving customer" });
  }
};

// Controller to get all customers
const getCustomers = async (req, res) => {
  try {
    const user = req.user;
    console.log(user.hash, "LIne j489");
    const customers = await Customer.find({hash:user.hash});

    // console.log(customers);

    const onlyData = customers.map(item =>({
      name:item.name,
      contactNumber:item.contactNumber,
      email:item.email,
      whatsappNumber:item.whatsappNumber,
      // hash:item.hash
    }))

    return res.status(200).json({ data: onlyData, code: 200 });
  } catch (error) {
    res.status(500).json({ message: "Error fetching customers" ,error:error.message});
  }
};

const getTotalCustomers = async (req, res) => {
  const user = req.user; // Assuming user ID is stored in req.user

  try {
    const totalCustomers = await Customer.countDocuments({
      hash: user.hash,
    });
    res.status(200).json({
      msg: `Total customers for this user: ${totalCustomers}`,
      totalCustomers,
    });
  } catch (error) {
    res.status(500).json({ message: "Error fetching total customers count" });
  }
};

module.exports = {
  addCustomer,
  getCustomers,
  getTotalCustomers,
};
