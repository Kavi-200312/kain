const jwt = require("jsonwebtoken");
const { User } = require("../Module/User");
const RefreshToken = require("../Module/RefreshToken");  // A new model for storing refresh tokens


const registerUser = async (req, res) => {
    try {
        const { email, password, mobilenumber, username } = req.body;

        // Check if required fields are provided
        if (!email || !password || !mobilenumber || !username) {
            return res.status(200).json({ code: 400, message: "Details missing" });
        }

        // Validate email format
        if (!validator.isEmail(email)) {
            return res.status(200).json({ code: 400, message: "Invalid email format" });
        }

        // Validate username (only alphabetic, 3-35 characters)
        const usernameRegex = /^[A-Za-z]{3,35}$/;
        if (!usernameRegex.test(username)) {
            return res.status(200).json({ code: 400, message: "Username must be alphabetic and between 3 to 35 characters long" });
        }

        // Validate mobilenumber (e.g., ensure it has 10 digits)
        const mobileNumberRegex = /^[6789][0-9]{9}$/;
        if (!mobileNumberRegex.test(mobilenumber)) {
            return res.status(200).json({ code: 400, message: "Invalid mobile number format" });
        }

        // Check if email or mobile number already exists in the database
        const existedUserEmail = await User.findOne({ email: email });
        const existedMobileNumber = await User.findOne({ mobile_number: mobilenumber });

        if (existedUserEmail) {
            return res.status(200).json({ code: 400, message: "Email already registered" });
        }

        if (existedMobileNumber) {
            return res.status(200).json({ code: 400, message: "Mobile number already exists" });
        }

        // Create the new user
        const user = await User.create({
            fullname: username,
            email: email,
            password: password,
            mobile_number: mobilenumber
        });

        // Select sensitive fields to return (exclude password, refreshToken, and mobile_number)
        const createdUser = await User.findById(user._id).select("-password -refreshToken -mobile_number");

        if (!createdUser) {
            return res.status(200).json({ code: 500, message: "Something went wrong" });
        }

        return res.status(200).json({ code: 200, message: "User created successfully" });

    } catch (error) {
        return res.status(200).json({ code: 500, message: error.message });
    }
};


const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    // console.log(password,email);
    // Check user credentials
    const user = await User.findOne({ email });
    if (!user || !(await user.isPasswordCorrect(password))) {
      return res.status(400).json({ code: 400, message: "Invalid email or password" });
    }
    // console.log(user);
    
    const oldRefreshToken = await RefreshToken.findOne({email_hash:user.email_hash})
    console.log(oldRefreshToken);

    if (oldRefreshToken && oldRefreshToken.expiresAt < Date.now()) {
        return res.status(403).json({ message: "old token removed" });
      }

    // Generate tokens

    const { accessToken, refreshToken } = await generateAccessAndRefreshTokens(user);
    
    console.log(refreshToken ,"             ",accessToken);
    // Save the refresh token in the database with an expiration of 30 days
    const refreshTokenDoc = new RefreshToken({
      userId: user._id,
      email_hash:user.email_hash,
      refreshToken,
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days expiration
    });

    await refreshTokenDoc.save();  // Save refresh token to DB
    // console.log(email_hash,"                   ",refreshToken,"                ",accessToken);
    return res.status(200).json({
      code: 200,
      data:user.email_hash,
      accessToken: accessToken,
      refreshToken: refreshToken,  // Send refresh token to frontend (stored in localStorage)
      message: "Logged in successfully",
    });
  } catch (error) {
    return res.status(500).json({ code: 500, message: error.message });
  }
};



const generateAccessAndRefreshTokens = async (user) => {
  const payload = {
    email_hash: user.email_hash,
    role: "user",
    date: user.createdAt,
  };

  const accessToken = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, {
    expiresIn: "10m",  // Access token expires in 15 minutes
  });

  const refreshToken = jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, {
    expiresIn: "30d",  // Refresh token expires in 30 days
  });

  return { accessToken, refreshToken };
};


module.exports={registerUser,userLogin,generateAccessAndRefreshTokens}
