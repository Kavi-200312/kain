const axios = require('axios');

const PaymentProcess = async (req,res)=>{
    const {amount}  = req.body;
    console.log(amount);

    const response = await axios.post('/zustpe',amount)
    if(!response){
        return res.status(400).json({message:"Something went wrong"})
    }
    return res.status(200).json({message:"Payment successfull"})

}

module.exports = PaymentProcess;