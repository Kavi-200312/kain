const jwt = require('jsonwebtoken');
// const { User } = require('../Module/User');
const Blacklist = require('../Module/BlackList');
const { ACCESS_TOKEN_SECRET_KEY, REFRESH_TOKEN_SECRET_KEY, ACCESS_TOKEN_EXPIRY, REFRESH_TOKEN_EXPIRY } = process.env;

// Function to add a token to the blacklist
const blacklistToken = async (token) => {
    const decodedToken = jwt.decode(token); // Decode the JWT to get the expiry
    const expiresAt = decodedToken.exp ? new Date(decodedToken.exp * 1000) : null;

    // Add the token to MongoDB blacklist
    const blacklistEntry = new Blacklist({
        token,
        expiresAt,
    });

    await blacklistEntry.save();
};

// Logout function to blacklist token
const userLogout = async (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
        // Blacklist the token
        await blacklistToken(token);
        return res.status(200).json({ message: 'Logged out successfully' });
    } else {
        return res.status(400).json({ message: 'No token provided' });
    }
};

module.exports = { userLogout };
