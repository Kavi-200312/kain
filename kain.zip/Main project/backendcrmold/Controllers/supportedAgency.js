const AgencyModel = require("../Module/AgencyModel");

const customerDetailsRenewAgency = async (req, res) => {
  try {
    const { customerName, policyNumber, dob, selectedAgency } = req.body;

    if (!customerName || !policyNumber || !selectedAgency) {
      return res.status(400).json({
        msg: "Customer Name, policyNumber,selectedAgency are required.",
      });
    }

    const customernameRegex = /^[A-Za-z\s]+$/;
    if (!customernameRegex.test(customerName)) {
      return res.status(400).json({
        message: "Name must be alphabetic and between 3 to 35 characters long",
      });
    }

    const dobDate = new Date(dob);
    const currentDate = new Date();

    // Ensure DOB is a valid date
    if (isNaN(dobDate.getTime())) {
      return res.status(400).json({
        msg: "Invalid Date of Birth format.",
      });
    }

    const minAgeDate = new Date(
      currentDate.setFullYear(currentDate.getFullYear() - 65)
    );
    const maxAgeDate = new Date(
      currentDate.setFullYear(currentDate.getFullYear() - 18)
    );

    if (dobDate < maxAgeDate || dobDate < minAgeDate) {
      return res.status(400).json({
        msg: "Date of Birth must be between 18 and 65 years ago.",
      });
    }

    if (!/^\d{8,10}$/.test(policyNumber)) {
      return res.status(400).json({
        msg: "Policy Number must be a number and between 8 to 10 digits.",
      });
    }

    const response = await AgencyModel.create({
      selectedAgency,
      customerName,
      policyNumber,
      dob,
    });

    await response.save();
    console.log(response);

    return res.status(201).json({
      message: "Customer details send successfully.",
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "server error", error: error.message });
  }
};

module.exports = customerDetailsRenewAgency;
