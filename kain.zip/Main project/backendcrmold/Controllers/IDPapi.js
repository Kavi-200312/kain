const session = require("express-session");
const passport = require("passport");
const express = require("express")
const loginIdp =  (req, res, next)=> {
      console.log("-----------------------------");
      console.log("/Start login handler");
      next();
    //   0;
    }


  const loginCallback =  (req, res, next) => {
    passport.authenticate("oidc", {
      successRedirect: "/user",
      failureRedirect: "/",
    })(req, res, next);
  }
  

//   app.get("/", (req, res) => {
//     res.send(" <a href='/login'>Log In with OAuth 2.0 Provider </a>");
//   });



  const userIdp = (req, res) => {  //get
    res.header("Content-Type", "application/json");
    res.end(
      JSON.stringify(
        { tokenset: req.session.tokenSet, userinfo: req.session.userinfo },
        null,
        2
      )
    );
  };
  
  const verifyIdp = (req, res) => {  //post
    
    const { code, state, iss } = req.body;
  };
  

  module.exports= {loginIdp,loginCallback,userIdp,verifyIdp}