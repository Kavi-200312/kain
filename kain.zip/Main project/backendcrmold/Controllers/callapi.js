const axios = require('axios');
const Call = require('../Module/Call');

const InitiateCall = async (req, res) => {
  const {  CustomerNumber } = req.body;
  const AdminNumber = "8925824341";

  const phonePattern = /^[6-7-8-9]\d{9}$/;

  try {
    // Validate AdminNumber and CustomerNumber format
    if (!AdminNumber || !phonePattern.test(AdminNumber)) {
      return res.status(400).json({ 
        message: "Invalid Admin number. Please provide a valid 10-digit number starting with 6, 7, 8, or 9." 
      });
    }
    
    if (!CustomerNumber || !phonePattern.test(CustomerNumber)) {
      return res.status(400).json({ 
        message: "Invalid Customer number. Please provide a valid 10-digit number starting with 6, 7, 8, or 9." 
      });
    }

    // Initiate the call using the external API
    const response = await axios.post(process.env.API_URL, {
      AdminNumber,
      CustomerNumber: "8925824352",
    });

    // Save the call data in the database
    const newCall = new Call({
      AdminNumber,
      CustomerNumber,
      status: response.data.status || 'initiated', // Update as per your API response
    });

    await newCall.save(); // Save the call details in the database

    res.status(200).json({
      message: "Call initiated successfully.",
      callData: newCall, // Optionally return the saved call data
    });
  } catch (error) {
    console.error("Error initiating call:", error);

    // Handle errors related to the external API
    if (error.response) {
      // Errors from the external API response
      return res.status(502).json({ 
        message: "Failed to initiate call through the external API.",
        details: error.response.data 
      });
    }

    // Handle other types of errors (e.g., database errors, network issues)
    res.status(500).json({ message: "Failed to initiate call due to server error." });
  }
};

module.exports = { InitiateCall };