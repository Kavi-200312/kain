const Pipeline = require("../Module/Pipeline");
const multer = require("multer");

// Controller to add new pipeline data
const addPipelineData = async (req, res) => {
  const {
    customerName,
    referredBy,
    description,
    status,
    contactNumber,
    billerName,
    policyNumber,
    startingDate,
    endingDate,
    DOB,
    amountPaid,
    document,
  } = req.body;
  console.log(contactNumber);

  try {
    const user = req.user;
    // Validate required fields for "add" action
    if (!customerName || !referredBy || !description) {
      return res.status(400).json({
        msg: "Customer Name, Referred By, and Description are required.",
      });
    }

    const customernameRegex = /^[A-Za-z\s]+$/;
    if (
      !customernameRegex.test(customerName) ||
      !customernameRegex.test(referredBy)
    ) {
      return res.status(400).json({
        message: "Name must be alphabetic and between 3 to 35 characters long",
      });
    }

    if (description.length > 160) {
      return res
        .status(400)
        .json({ message: "Description maximum 160 characters only" });
    }
    if (!/^[6-9]\d{9}$/.test(contactNumber)) {
      return res
        .status(400)
        .json({
          msg: "Please provide a valid 10-digit Indian contact number starting with 6-9.",
          code: 400,
        });
    }

    // Create a new pipeline entry using the validated schema
    const savedEntry = await Pipeline.create({
      customerName,
      referredBy,
      description,
      status,
      contactNumber,
      // billerName, // optional field for closed status
      // policyNumber,
      // startingDate,
      // endingDate,
      // DOB,
      // amountPaid,
      // document,
      hash: user.hash,
    });

    return res.status(200).json({
      msg: "New pipeline data added to the database.",
      data: {
        customerName: savedEntry.customerName,
        contactNumber: savedEntry.contactNumber,
        referredBy: savedEntry.referredBy,
        description: savedEntry.description,
        status: savedEntry.status,
      },
    });
  } catch (error) {
    console.error("Failed to add pipeline data:", error);
    if (error.name === "ValidationError") {
      return res
        .status(400)
        .json({ msg: "Validation error", details: error.message });
    }
    res.status(500).json({ error: "Failed to add pipeline data" });
  }
};


const storage = multer.memoryStorage(); // Store file in memory


const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type, only PDFs and images are allowed'), false);
    }
  },
}).single("document"); // "document" is the form field name



const updatePipelineData = async (req, res) => {
  const {
    customerName,
    referredBy,
    description,
    status,
    policy,
    billerName,
    policyNumber,
    startingDate,
    endingDate,
    DOB,
    amountPaid,
  } = req.body;

  // console.log(
  //   customerName,
  //   referredBy,
  //   description,
  //   status,
  //   policy,
  //   billerName,
  //   policyNumber,
  //   startingDate,
  //   DOB,
  //   amountPaid
  // );
  const document = req.file ? req.file.buffer : null; // Check if the file exists in req.file

  try {
    // Find the pipeline item using customerName, referredBy, and description
    const pipelineItem = await Pipeline.findOne({
      customerName,
      referredBy,
      description,
    });

    if (!pipelineItem) {
      return res.status(404).json({ message: "Pipeline item not found" });
    }

    // Validate if the status is "Closed" and the billerName is provided
    if (status === "Closed" && !billerName) {
      return res
        .status(400)
        .json({ message: "Biller Name is required when closing the pipeline" });
    }

    // Update the status and other fields
    pipelineItem.status = status;
    if (status === "Closed") {
      pipelineItem.policy = policy;
      pipelineItem.billerName = billerName;
      pipelineItem.policyNumber = policyNumber;
      pipelineItem.startingDate = startingDate;
      pipelineItem.endingDate = endingDate;
      pipelineItem.DOB = DOB;
      pipelineItem.amountPaid = amountPaid;

      // If a document was uploaded, save it in the document field as binary data
      if (document) {
        pipelineItem.document = document; // Store the file as a buffer (binary data)
      }
    }

    await pipelineItem.save();

    return res.status(200).json({
      message: "Status updated successfully",
      data: {
        customerName: pipelineItem.customerName,
        referredBy: pipelineItem.referredBy,
        description: pipelineItem.description,
        status: pipelineItem.status,
      },
    });
  } catch (error) {
    console.error("Error updating pipeline data:", error);
    return res.status(500).json({ message: "Failed to update pipeline data" });
  }
};



const getPolicyDetails = async (req, res) => {
  try {
    const user = req.user;
    const pipelineData = await Pipeline.find({ hash:user.hash});

    const onlyData = pipelineData.map((item) => ({
      customerName: item.customerName,
      contactNumber: item.contactNumber,
      referredBy: item.referredBy,
      description: item.description,
      status: item.status,
      policy: item.policy,
      billerName: item.billerName,
      policyNumber: item.policyNumber,
      startingDate: item.startingDate,
      endingDate: item.endingDate,
      DOB: item.DOB,
      amountPaid: item.amountPaid,
      document:item.document
    }));

    res.status(200).json({
      msg: "All policy data retrieved from the database.",
      data: onlyData,
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ error: "Failed to fetch pipeline data" });
  }
};


// Controller to get all pipeline data
const getPipelineData = async (req, res) => {
  try {
    const user = req.user;
    console.log(user.hash,"......................getPipeline");

    const pipelineData = await Pipeline.find({ hash:user.hash });
    const filteredData = pipelineData.filter((item) => item.status !== "Closed");

    const onlyData = filteredData.map((item) => ({
      customerName: item.customerName,
      referredBy: item.referredBy,
      description: item.description,
      status: item.status,
    }));

    res.status(200).json({
      msg: "All pipeline data retrieved from the database.",
      data: onlyData,
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ error: "Failed to fetch pipeline data" });
  }
};

// Controller to get pipeline status counts
const getPipelineStatusCounts = async (req, res) => {
  try {
    const user = req.user;
    const statusCounts = await Pipeline.aggregate([
      { $match: { hash: user.hash } },
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 },
        },
      },
    ]);

    const formattedCounts = {
      Referral: 0,
      Lead: 0,
      InDiscussion: 0,
      Customer: 0,
      Closed: 0,
    };

    statusCounts.forEach((item) => {
      formattedCounts[item._id.replace(/\s/g, "")] = item.count;
    });

    return res.status(200).json({
      msg: "Pipeline status counts retrieved successfully",
      data: formattedCounts,
    });
  } catch (error) {
    console.log("Error fetching pipeline status counts:", error);
    return res
      .status(500)
      .json({ error: "Failed to fetch pipeline status counts" });
  }
};
module.exports = {
  addPipelineData,
  getPipelineData,
  updatePipelineData,
  getPipelineStatusCounts,
  updatePipelineData,
  getPolicyDetails,
  upload,
};
