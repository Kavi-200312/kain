const { default: axios } = require("axios");

const UpcomingPayments = async (req, res) => {
  try {
    // const zustpeUpcomingPaymentDetails = await axios.get("/zustpe")
    const zustpeUpcomingPaymentDetails = [
      {
        customerName: "kavi",
        policyNumber: "234543",
        renewalDate: "12/12/2024",
        billAmount: "1000",
      },
      {
        customerName: "kavi",
        policyNumber: "234543",
        renewalDate: "12/12/2024",
        billAmount: "1000",
      },
      {
        customerName: "kavi",
        policyNumber: "234543",
        renewalDate: "12/12/2024",
        billAmount: "1000",
      },
      {
        customerName: "kavi",
        policyNumber: "234543",
        renewalDate: "12/12/2024",
        billAmount: "1000",
      },
    ];
    const onlyData = zustpeUpcomingPaymentDetails.map((item)=>({
      customerName: item.customerName,
      policyNumber: item.policyNumber,
      renewalDate: item.renewalDate,
      billAmount: item.billAmount,
    }))
    return res.status(200).json({
      message: "data fetch successfull",
      data: onlyData,
      code: 200,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "something went wrong can't retrive the data" });
  }
};


module.exports = UpcomingPayments